"""Run INSIDE NX 2306: Tools -> Journal -> Play.
Export the currently displayed part's drawing sheets to PDF.
The external compare_drawings.py program compares this exported PDF to the old revision.
"""
import os
import NXOpen

def main():
    s=NXOpen.Session.GetSession()
    lw=s.ListingWindow
    lw.Open()
    part=s.Parts.Work
    if part is None:
        lw.WriteLine('ERROR: Open a drawing part as the work part.')
        return
    sheets=list(part.DrawingSheets)
    if not sheets:
        lw.WriteLine('ERROR: No drawing sheets in work part.')
        return
    base=part.FullPath
    folder=os.path.dirname(base) if base else os.path.expanduser('~')
    name=os.path.splitext(os.path.basename(base))[0] if base else 'NX_WorkPart'
    output=os.path.join(folder, name+'_CURRENT.pdf')
    builder=part.PlotManager.CreatePrintPdfbuilder()
    try:
        builder.Action=NXOpen.PrintPDFBuilder.ActionOption.Native
        builder.Filename=output
        builder.Colors=NXOpen.PrintPDFBuilder.Color.BlackOnWhite
        builder.Size=NXOpen.PrintPDFBuilder.SizeOption.ScaleFactor
        builder.Scale=1.0
        builder.SourceBuilder.SetSheets(sheets)
        builder.Commit()
        lw.WriteLine('PDF export successful: '+output)
        lw.WriteLine('Now run compare_drawings.py outside NX.')
    except Exception as ex:
        lw.WriteLine('PDF export failed: '+str(ex))
        raise
    finally:
        builder.Destroy()

if __name__=='__main__':main()
