NX 2306 Drawing Revision Comparator
===================================
1) Inside NX: Tools -> Journal -> Play -> export_current_nx_drawing.py
   The work part must have drawing sheets. The journal exports a CURRENT.pdf beside the saved part.
   If you use Teamcenter-managed parts, modify the export folder for a valid writable local location.
   NX Open Python API environment varies by installed version; verify export builder properties.
2) Outside NX, install Python 3.10+ with:
   py -m pip install -r requirements.txt
   (or python -m pip install -r requirements.txt)
3) Compare in Windows Command Prompt:
   py compare_drawings.py --current "C:\\Drawings\\Part_CURRENT.pdf" --previous "C:\\Drawings\\Part_OLD.pdf" --out "C:\\Drawings\\Comparison"
4) Open Comparison/comparison_report.pdf; review all orange boxes and red/blue changes.

Optional mask title block differences:
   --mask .77,.80,1,1
The numbers are normalized fractions of the sheet width and height; this hides that region from visual change detection. DO NOT mask relevant changes.

Limitations:
- The script compares geometry/annotations visually, not editable NX object IDs or GD&T semantics.
- PDF text differences are reported as word counts in JSON, not certified text comparison.
- Sheets are paired by PAGE ORDER (not sheet ID); view shifts, scale changes, raster print artifacts, hidden parts, or page-size differences can cause false positives.
- Single small page translations are auto-corrected; rotations, rescaling and shifted views are not. Verify page sizes and alignment warnings.
- Missing or extra pages are reported but not compared.
- The old PDF must be unencrypted and accessible. No OCR is performed.
- A clean report does NOT mean the two engineering drawings are functionally equivalent.
