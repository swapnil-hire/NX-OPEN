"""Compare NX drawing exports to a previous-revision PDF (outside NX).
Usage: python compare_drawings.py --current current.pdf --previous previous.pdf --out comparison
Dependencies: pip install pymupdf opencv-python numpy reportlab pillow
Results: comparison_report.pdf, changes.csv, summary.json, PNG per sheet.
NOTE: A visual change is not necessarily an engineering change. Review every flagged area.
"""
import argparse, csv, json, os
from pathlib import Path
import fitz
import cv2
import numpy as np
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch


def render(page, dpi):
    pm = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72), colorspace=fitz.csRGB, alpha=False)
    return np.frombuffer(pm.samples, dtype=np.uint8).reshape(pm.height, pm.width, 3).copy()


def ink(rgb, threshold):
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    return ((gray < threshold).astype(np.uint8) * 255)


def pad_to(arr, h, w):
    ret = np.full((h, w, 3), 255, dtype=np.uint8)
    ret[:arr.shape[0], :arr.shape[1]] = arr
    return ret


def align_translation(reference_ink, target_ink, max_shift):
    # Estimate small print/export translations, never stretch/rotate engineering geometry.
    reference = cv2.GaussianBlur(reference_ink.astype(np.float32) / 255.0, (5, 5), 0)
    moving = cv2.GaussianBlur(target_ink.astype(np.float32) / 255.0, (5, 5), 0)
    shift, response = cv2.phaseCorrelate(reference, moving)
    dx, dy = shift
    if not np.isfinite(dx + dy) or abs(dx) > max_shift or abs(dy) > max_shift or response < 0.03:
        return 0.0, 0.0, float(response) if np.isfinite(response) else 0.0
    return dx, dy, float(response)


def place_shifted(img, dx, dy):
    # phaseCorrelate(ref,target) shift is how target moved; shift target BACK.
    h, w = img.shape[:2]
    warp = np.float32([[1, 0, -dx], [0, 1, -dy]])
    return cv2.warpAffine(img, warp, (w, h), flags=cv2.INTER_NEAREST, borderValue=(255, 255, 255))


def get_text_delta(old_page, new_page):
    from collections import Counter
    old = Counter(w[4] for w in old_page.get_text('words'))
    new = Counter(w[4] for w in new_page.get_text('words'))
    added = list((new - old).elements())
    removed = list((old - new).elements())
    return {'added_words': added[:120], 'removed_words': removed[:120],
            'added_count': len(added), 'removed_count': len(removed)}


def compare_page(old_page, new_page, dpi, threshold, tolerance, min_area, max_shift, mask_regions):
    old = render(old_page, dpi)
    new = render(new_page, dpi)
    h, w = max(old.shape[0], new.shape[0]), max(old.shape[1], new.shape[1])
    old, new = pad_to(old, h, w), pad_to(new, h, w)
    old_ink = ink(old, threshold)
    new_ink = ink(new, threshold)
    dx, dy, score = align_translation(old_ink, new_ink, max_shift)
    new = place_shifted(new, dx, dy)
    new_ink = ink(new, threshold)
    # Small dilations absorb anti-aliasing and line thickness variation.
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * tolerance + 1, 2 * tolerance + 1))
    old_only = cv2.bitwise_and(old_ink, cv2.bitwise_not(cv2.dilate(new_ink, k)))
    new_only = cv2.bitwise_and(new_ink, cv2.bitwise_not(cv2.dilate(old_ink, k)))
    difference = cv2.bitwise_or(old_only, new_only)
    for x0, y0, x1, y1 in mask_regions:
        x0, x1 = int(x0 * w), int(x1 * w)
        y0, y1 = int(y0 * h), int(y1 * h)
        difference[y0:y1, x0:x1] = 0
        old_only[y0:y1, x0:x1] = 0
        new_only[y0:y1, x0:x1] = 0
    # Merge nearby changed strokes into review boxes.
    merge = cv2.dilate(difference, cv2.getStructuringElement(cv2.MORPH_RECT, (13, 13)), iterations=1)
    contours, _ = cv2.findContours(merge, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for contour in contours:
        x, y, bw, bh = cv2.boundingRect(contour)
        # Count changed pixels, not dilated area.
        count = int(cv2.countNonZero(difference[y:y+bh, x:x+bw]))
        if count >= min_area:
            boxes.append({'x': x, 'y': y, 'w': bw, 'h': bh, 'changed_pixels': count,
                          'normalized_box': [round(x/w,5), round(y/h,5), round((x+bw)/w,5), round((y+bh)/h,5)]})
    boxes.sort(key=lambda b: (b['y'], b['x']))
    kept = np.zeros_like(difference)
    for b in boxes:
        x,y,bw,bh = b['x'],b['y'],b['w'],b['h']
        kept[y:y+bh,x:x+bw] = 255
    vis = new.copy()
    # New-only strokes = blue; previous-only = red, over current PDF.
    vis[cv2.bitwise_and(new_only, kept)>0] = (28, 85, 240)
    vis[cv2.bitwise_and(old_only, kept)>0] = (235, 30, 45)
    for idx,b in enumerate(boxes,1):
        x,y,bw,bh=b['x'],b['y'],b['w'],b['h']
        cv2.rectangle(vis, (x,y), (x+bw,y+bh), (215, 135, 0), 2)
        cv2.putText(vis, str(idx), (x, max(15,y-4)), cv2.FONT_HERSHEY_SIMPLEX, .5, (15,105,180), 1, cv2.LINE_AA)
    return vis, boxes, {'dx_px': round(dx,2), 'dy_px': round(dy,2), 'alignment_score':round(score,4),
                        'old_size_pixels': [int(old.shape[1]), int(old.shape[0])],
                        'new_size_pixels': [int(new.shape[1]), int(new.shape[0])],
                        'page_size_mismatch': bool(abs(old_page.rect.width-new_page.rect.width)>.5 or abs(old_page.rect.height-new_page.rect.height)>.5),
                        'text':get_text_delta(old_page,new_page)}


def pdf_report(out_file, data, png_paths):
    styles = getSampleStyleSheet()
    doc=SimpleDocTemplate(str(out_file), pagesize=(11.69*inch,8.27*inch), leftMargin=36,rightMargin=36,topMargin=32,bottomMargin=30)
    elements=[Paragraph('NX Drawing Revision Comparison',styles['Title']),
              Paragraph('Red: only in previous PDF. Blue: only in current PDF. Orange boxes: candidate changed regions. Neither pixel differences nor PDF text extraction prove engineering equivalence.',styles['BodyText']),Spacer(1,12),
              Paragraph('Previous: '+data['previous'],styles['BodyText']),Paragraph('Current: '+data['current'],styles['BodyText']),Spacer(1,10)]
    for i, (pg,png) in enumerate(zip(data['pages'],png_paths),1):
        elements.append(Paragraph('Sheet %s — %s change region(s)'%(i,pg['change_regions']),styles['Heading2']))
        elements.append(Paragraph('Alignment shift: (%s, %s) px. Page-size mismatch: %s. Extractable words added: %s; removed: %s.'%(
            pg['dx_px'],pg['dy_px'],pg['page_size_mismatch'],pg['text']['added_count'],pg['text']['removed_count']),styles['BodyText']))
        img = Image(str(png))
        factor=min(10.5*inch/img.imageWidth,6.35*inch/img.imageHeight)
        img.drawWidth,img.drawHeight=img.imageWidth*factor,img.imageHeight*factor
        elements.append(img)
        if i<len(png_paths):elements.append(PageBreak())
    doc.build(elements)


def main():
    p=argparse.ArgumentParser(description='Revision comparison: NX-exported current PDF vs previous PDF')
    p.add_argument('--current', required=True,help='PDF exported from current NX drawing')
    p.add_argument('--previous',required=True,help='PDF print of previous revision')
    p.add_argument('--out', default='nx_compare_output')
    p.add_argument('--dpi',type=int,default=150)
    p.add_argument('--threshold',type=int,default=205,help='Pixel value below this is ink (0-255)')
    p.add_argument('--tolerance',type=int,default=2,help='Ignored line proximity, pixels')
    p.add_argument('--min-area',type=int,default=18,help='Min changed ink pixels per region')
    p.add_argument('--max-shift',type=int,default=40)
    p.add_argument('--mask',action='append',default=[],help='Ignore normalized rectangle x0,y0,x1,y1 e.g. .78,.82,1,1 (title block). Repeat.')
    a=p.parse_args()
    if a.dpi < 72 or a.dpi > 400: p.error('--dpi must be 72..400')
    masks=[]
    for arg in a.mask:
        try: rect=tuple(float(x) for x in arg.split(','))
        except ValueError:p.error('Bad --mask rectangle')
        if len(rect)!=4 or not (0<=rect[0]<rect[2]<=1 and 0<=rect[1]<rect[3]<=1):p.error('Bad --mask bounds')
        masks.append(rect)
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    with fitz.open(a.previous) as old, fitz.open(a.current) as new:
        n=min(len(old),len(new));data={'previous':os.path.abspath(a.previous),'current':os.path.abspath(a.current),
                                      'previous_page_count':len(old),'current_page_count':len(new),'mask_regions':masks,'pages':[]}
        pngs=[]; rows=[]
        for ix in range(n):
            vis,boxes,extra=compare_page(old[ix],new[ix],a.dpi,a.threshold,a.tolerance,a.min_area,a.max_shift,masks)
            png=out / ('sheet_%02d_overlay.png'%(ix+1)); cv2.imwrite(str(png),cv2.cvtColor(vis,cv2.COLOR_RGB2BGR)); pngs.append(png)
            data['pages'].append({'sheet_index':ix+1,'change_regions':len(boxes),'boxes':boxes,**extra})
            for j,b in enumerate(boxes,1):rows.append([ix+1,j,b['x'],b['y'],b['w'],b['h'],b['changed_pixels'],*b['normalized_box']])
            print('Sheet %d: %d candidate change regions'%(ix+1,len(boxes)))
        if len(old)!=len(new):print('WARNING: Page count differs; unmatched sheets not compared.')
    with open(out/'changes.csv','w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['sheet','region','x_px','y_px','width_px','height_px','changed_ink_pixels','norm_left','norm_top','norm_right','norm_bottom']);writer.writerows(rows)
    with open(out/'summary.json','w',encoding='utf-8') as f:json.dump(data,f,indent=2)
    if pngs:pdf_report(out/'comparison_report.pdf',data,pngs)
    print('Output:',out)
    print('REVIEW REQUIRED: A clean visual diff is NOT a verified engineering drawing check.')

if __name__=='__main__':main()
