# NX 2306 exterior-export journal — VB.NET

This package provides a standalone VB.NET NXOpen journal that executes inside NX. It can use the JSON downloaded from your Exterior configuration website, or its built-in defaults. No website connection or .dlx file is required when the journal runs.

**Validation status:** code reviewed against published NXOpen/UF API references; static source and configuration checks were performed. This environment has neither an NX installation nor a VB.NET compiler. The journal has **not been compiled or runtime-tested in NX 2306**. Test with a copied, non-production assembly first. The API reference versions available for checking were NX 2022.1 and adjacent-release documentation, not an installed NX 2306 API assembly.

## Quick start in NX

1. Extract the ZIP to a local folder.
2. Open a **copy** of your assembly in NX 2306 and fully load the required component geometry.
3. Make the displayed top-level assembly the work part. In-place work-component mode is rejected.
4. Use **Tools → Journal → Play**, select `NX2306_Exterior_Export.vb`, and play it.
5. In the dialog, optionally select your website's `*_configuration.json`. Leave this field blank to use the defaults.
6. Choose an existing output folder and start with **Inspect only**.
7. Review the NX Listing Window and the generated `inventory.csv`. Use its exact occurrence paths if you need selected scope or explicit exclusions.
8. Run again with **Build and review** to create geometry without exporting, or **Build, review and export** to create geometry and review the actual body counts before exporting.

For a first test without any website setup, use a simple assembly with two fully loaded components, leave the JSON field blank and select Inspect only. The supplied `Example_Exterior_Config.json` is also a valid example generated with the website's configuration code.

The default plan is: entire assembly, visible components only, exterior surfaces, fine recognition, attempt qualifying hole closure, sew, no solid creation, STEP AP242 plus native-version text Parasolid. Source components stay in the assembly tree. The result is created as unassociated geometry owned by the current assembly part; the journal does not create a new part.

The journal also runs pure-logic startup checks in NX for direction vectors, occurrence-path boundaries, unit scaling, CSV escaping and invalid settings. These do not test the NX geometry or translator APIs and have not been executed in this authoring environment.

## Output

Every run creates a separate folder such as:

```text
NX_Exterior_20261015_190000_ab12cd34/
    report.txt
    inventory.csv
    bodies.csv
    assembly_exterior.stp
    assembly_exterior.x_t
```

`bodies.csv` is written after geometry is available. CAD files are created only after the export review is accepted. Inspect-only runs write reports but do not create geometry or CAD exports.

- `inventory.csv`: each inspected occurrence's canonical path, status, eligible body count, reference set and reason.
- `bodies.csv`: result body tags, names, sheet/solid classification and free-boundary-loop query where available.
- `report.txt`: configuration, actual part, processing status, warning/error details and export file status.
- Export file checks establish existence and nonzero size. They do not prove geometric fidelity or recipient compatibility. Reopen the output in a receiving CAD system before release.

## Supported settings and limits

| Setting | Journal behavior |
| --- | --- |
| Entire assembly | Includes eligible root-owned geometry and inspected component occurrences. |
| Selected subassembly | Uses the exact inventory path and its descendants. |
| Selected components | Uses exact occurrence paths, processing those occurrences' local bodies. It does not implicitly include a selected occurrence's descendants. |
| Visible only | Filters component/ancestor blanking, suppression, reference-set geometry and hidden prototype body layers. It also checks occurrence body blanking. This is not a camera-frustum, view-dependent-layer or screen-occlusion calculation. |
| Suppressed / empty-reference-set subtrees | Excluded; descendants are not individually traversed. Counts describe inspected occurrences, not a total of inaccessible descendants. |
| Leaf reference sets | Uses body membership from the selected reference set. |
| Subassembly reference sets | A relevant subassembly must use **Entire Part**. This version blocks custom assembly reference sets instead of guessing which child components they contain. Set this yourself in NX; the journal does not change reference sets. |
| Internal categories | Requires confirmed string attributes; no part-name guessing. Exact occurrence paths are also supported. |
| Standard quality | Six axial view directions, normal hidden-line resolution, 0.10 mm chordal tolerance. |
| Fine quality | 26 view directions, fine hidden-line resolution, 0.03 mm chordal tolerance. |
| Very fine quality | 26 view directions, very-fine hidden-line resolution, 0.01 mm chordal tolerance. |
| Close openings | Requests linked-exterior hole deletion. It closes qualifying interior edge loops; it does not promise to cap every arbitrary open boundary or repair all gaps. |
| Sew | Attempts sheet sewing at 0.01 mm tolerance. Values are converted to work-part units for inch parts. |
| Solid target | Requires sewing and conditional solid creation. A closed volume is required. If the sew attempt fails, its changes are undone and the extracted sheets are retained. Actual solids/sheets are counted. |
| Surface target | Requests sheet output from sewing. Adjacent extracted faces from the same source body are already joined by the linked-exterior operation, even with the additional sewing step off. |
| Single body | A target only. Disconnected geometry is reported; no artificial bridges, bounding solids or boolean-union substitutes are created. |
| Unassociated result | Removes parameters only from newly created journal-owned output, before/after sewing. Original source body parameters are not removed. |
| Existing exterior | Lets you select bodies already owned by the work part. Journal-tagged results are checked initially. Existing geometry is exported unchanged; it is not re-extracted or stripped of dependencies. |
| Preview isolation | Temporarily hides top-level source components and other work-part bodies for the result review, then restores changed blanking states in a `Finally` block. |
| STEP | AP214 or AP242; explicit result-body selection; native file output; geometry filters. |
| Parasolid | Text `.x_t`; current or exact supported version from the installed exporter's enum. No nearest-version substitution. |
| Export both | Executes STEP and text Parasolid separately and reports each outcome, including partial failures. |
| Binary Parasolid `.x_b` | **Not enabled.** Export preflight rejects this setting. Choose Text in the website. A verified NX 2306 binary-export recording/API mapping is required before adding it. |

The assembly reference in the website is treated as a descriptive label, not a binding to a CAD session. The actual NX work part and exact paths are shown during review. Always check them before creating or exporting geometry.

## Confirmed internal-component exclusions

To exclude a particular internal component without adding attributes:

1. Run Inspect only.
2. Copy the exact path from `inventory.csv`, for example `AXLE_ASSY/CARRIER_1/GEAR_1`.
3. In the website, enable internal exclusions and add the path under explicit component exclusions.
4. Download the JSON again and select it in the journal.

An explicit exclusion also excludes descendants of that occurrence. A path that cannot be found is a blocking inspection error; it is not silently ignored.

For reusable category rules, add these **string** attributes yourself to the component occurrence or prototype part:

| Attribute | Values |
| --- | --- |
| `EXTERIOR_INTERNAL_CATEGORY` | `gears`, `bearings`, `fasteners`, `seals`, `other` |
| `EXTERIOR_INTERNAL` | `true`; used as `other` only if a category is absent |

The occurrence category takes precedence over the prototype category. The matching category must also be selected in the website configuration. An internal subassembly rule applies to descendants. The journal reads attributes but does not create or change them.

Untagged components are not excluded solely because a category is checked. Exterior recognition may still omit fully enclosed faces, but that is not a substitute for reviewing the component exclusion inventory.

## Retaining or undoing geometry

- The journal never saves or closes an NX part and never overwrites a previous run's CAD outputs.
- A visible **NX Exterior - unassociated result** Undo mark surrounds new geometry creation. A fatal geometry failure attempts rollback to this mark.
- A failed sewing attempt rolls back only that attempt and retains the extracted sheets.
- Cancelling the final result review stops export but keeps successfully created geometry. Use NX Undo if you want to remove it.
- Rerunning extraction creates another result; it does not replace or delete previous results. Bodies tagged `NX_EXTERIOR_RESULT=v1` are excluded from new source extraction. Choose existing-exterior mode to export an earlier result.
- Removing a result with NX Undo does not delete previously exported files.
- An export failure retains geometry and any independently successful output. Inspect report.txt and any translator logs; a partially written file may remain in that run folder and must not be treated as a successful export.

## Environment requirements and troubleshooting

- Windows NX 2306 with NXOpen .NET journaling, solid-modeling operations and the required translators available in your installation/license configuration.
- Standard .NET Framework Windows Forms and `System.Web.Extensions`. The latter is loaded by reflection for JSON deserialization, avoiding an additional journal compile reference.
- No external Python installation or Visual Studio project is needed to play the `.vb` journal.
- Native output directories are used even when the assembly is managed in Teamcenter. No Teamcenter dataset is created, checked in or saved.
- If a component is unloaded/partially loaded, load its exact geometry in NX and rerun. The journal does not auto-load geometry or change load options.
- If a subassembly uses a custom reference set, set that relevant occurrence to Entire Part before rerunning this version.
- The exporter uses its installed STEP defaults. If an installation requires a specific settings file, add an optional `"stepSettingsFile": "C:\\...\\ugstep242.def"` string inside the JSON's `export` object. Use an actual settings file from your installation. The requested AP214/AP242 option is still explicitly set.
- If compilation reports an unknown member, retain the exact line/message. Validate it against your installed NX 2306 `NXOpen.dll`/`NXOpen.UF.dll`; the available web references are not a substitute for checking the installed release.

## Local NX test matrix

These runtime tests are **not yet executed** in this package. Run them on copied parts:

| Case | Expected check |
| --- | --- |
| No part / work part differs from display part | Stops before modification. |
| Fully loaded two-component assembly | Inspect lists candidate bodies and exact occurrence paths. |
| Same prototype repeated with translation/rotation | Each occurrence retains its assembly placement; no prototype-level deduplication. |
| Nested subassembly with Entire Part reference set | Descendants are included at top-level absolute placement. |
| Relevant custom subassembly reference set | Blocking inspection message, no extraction. |
| Unloaded visible component | Blocking inspection error, no partial exterior export. |
| Hidden or suppressed component | Excluded when applicable; visibility remains unchanged. |
| Explicit exclusion / confirmed category | Listed with its reason; excluded body is absent from candidates. |
| Invalid selected path | Blocking error; no silent selection fallback. |
| Millimeter and inch parts | Equivalent physical extraction/sew tolerance. |
| Open shell / disconnected housings | Actual multiple-sheet count and review warning; no fake single solid. |
| Closed connected exterior + solid target | Check whether a solid is produced, otherwise retained-sheet warning. |
| One already-closed sheet | Confirm installed sewing behavior; if unsupported, sheet fallback is reported. |
| Cancel geometry review / cancel final export | Before-build cancel creates nothing; final cancel retains geometry and writes no CAD file. |
| STEP AP214 / AP242 / supported Parasolid target / both | Reimport each successful output and compare geometry, units, placement and body counts. |
| Unsupported version / binary output | Preflight rejects it before extraction in export mode. |
| Translator failure in one format | Partial status identifies which file succeeded; do not use partial output. |
| Temporary preview isolation | Original source blanking states are restored on close/error. |
| NX Undo / rerun / existing exterior | Undo removes new result; rerun does not use prior tagged result as source; existing mode selects explicit owned bodies. |

## API references used

These are mirrors of Siemens-authored API reference material, not Siemens support guarantees for this installation:

- [UF linked-exterior functions and limitations](https://www.ugapi.com/doc/ufun/uf_linked_exterior/global.html)
- [UFModl .NET reference](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.UF.UFModl.html)
- [UFModl.LinkedExt structure](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.UF.UFModl.LinkedExt.html)
- [Assembly-context transforms](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.UF.UFSo.html)
- [SewBuilder](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.Features.SewBuilder.html)
- [StepCreator](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.StepCreator.html)
- [ParasolidExporter](https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.ParasolidExporter.html)

Key local checks remain: the installed NX 2306 method signatures, licensing, linked-exterior parameter removal, sewing a single closed sheet, and selection-only exporter behavior on your actual assemblies.
