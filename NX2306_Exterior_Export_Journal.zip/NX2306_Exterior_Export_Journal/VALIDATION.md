# Validation record

Date: 2026-10-15.

Completed in the authoring environment:

- Checked VB source strings, delimiters and matching Module/Class/Sub/Function/Property/Get/If/For/Try/Using blocks. No structural errors were found.
- Generated Example_Exterior_Config.json using the deployed website source's packageConfig function, rather than hand-reconstructing its schema.
- Reviewed the main success path: inspect → validate → undo mark → assembly-context transforms → exterior identification → extraction → remove output parameters → attempt sewing → remove result parameters → count → isolated review → restore visibility → selected-body export → reports.
- Reviewed failure paths: missing part; wrong work part; invalid configuration; missing occurrence; unloaded eligible component; custom subassembly reference set; no candidate body; exterior failure with rollback; sew failure with retained sheets; review cancellation; visibility restoration failure; unsupported export version/encoding; partial translator failure.
- Inspected all builder lifecycles for Finally cleanup. Geometry rollback is separate from recoverable export failures.
- Verified the ZIP integrity and compared its source file bytes with the delivered working copy.

Not completed here:

- VB.NET compilation: no VB.NET compiler is installed in this environment.
- NX 2306 runtime tests: NX and its assemblies/licenses are unavailable here.
- Geometry fidelity, repeated-instance placement, single-sheet solid conversion and STEP/Parasolid translator behavior on real assemblies.

API declarations were checked in mirrored Siemens-authored reference documentation (primarily NX 2022.1). That is not a claim that the code has been verified against an installed NX 2306 API assembly. Run the README test matrix on copied parts and retain the exact compiler/runtime diagnostic if your installation rejects a member.

Binary Parasolid is deliberately rejected before export; no unverified binary encoding mapping is included.
