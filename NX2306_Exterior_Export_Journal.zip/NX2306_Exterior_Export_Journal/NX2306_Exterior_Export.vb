' NX 2306 exterior export journal - version 1.0, 2026-10-15
' Run inside NX: Tools > Journal > Play. Do not run with Windows Python.
' Optional input: JSON downloaded from the Exterior configuration website.
' No third-party libraries or .dlx file required. Windows Forms is used.
'
' IMPORTANT VALIDATION STATUS
' Implemented against published NXOpen/UF interfaces (NX2022.1 and adjacent
' release documentation). NOT compiled or run in an NX 2306 installation here.
' First use: a copied, fully-loaded assembly; run Inspect only before Build.
' APIs, feature licenses, translators and binary Parasolid behavior need a
' local NX 2306 check. No new part is created; the existing part is not saved.
'
' Internal exclusions use exact occurrence paths or user attributes:
'   EXTERIOR_INTERNAL_CATEGORY = gears|bearings|fasteners|seals|other
'   EXTERIOR_INTERNAL = true  (maps to other when category is absent)
' Attribute values must be strings. No name-based internal-part guessing.
'
' Extraction uses UF hidden-line exterior identification, prototype bodies
' and per-occurrence assembly-context transforms. Linked-exterior output is
' immediately stripped of parameters, and only journal-owned output is sewn.
' Hole deletion closes qualifying internal sheet loops, NOT arbitrary gaps.
' Single-body and solid results are targets, never guaranteed.

Option Strict On
Option Explicit On

Imports System
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Reflection
Imports NXOpen
Imports NXOpen.UF
Imports NXOpen.Assemblies
Imports NXOpen.Features
Imports Forms = System.Windows.Forms
Imports Drawing = System.Drawing

Module NX2306ExteriorExport
    Private Const ResultAttribute As String = "NX_EXTERIOR_RESULT"
    Private Const ChordStandardMm As Double = 0.1
    Private Const ChordFineMm As Double = 0.03
    Private Const ChordVeryFineMm As Double = 0.01
    Private Const SewToleranceMm As Double = 0.01
    Private s As Session
    Private uf As UFSession
    Private wp As Part
    Private log As New List(Of String)
    Private issues As New List(Of String)
    Private notices As New List(Of String)
    Private rows As New List(Of OccurrenceRecord)
    Private candidates As New List(Of BodyRecord)
    Private runFolder As String = ""
    Private runStatus As String = "STARTED"

    Public Sub Main()
        s = Session.GetSession()
        uf = UFSession.GetUFSession()
        s.ListingWindow.Open()
        log.Clear() : issues.Clear() : notices.Clear() : rows.Clear() : candidates.Clear()
        runFolder = "" : runStatus = "STARTED"
        Dim outerMark As Session.UndoMarkId
        Dim markExists As Boolean = False
        Try
            RunPureSelfChecks()
            wp = s.Parts.Work
            If wp Is Nothing Then Throw New InvalidOperationException("Open a modeling part or assembly first.")
            If s.Parts.Display Is Nothing OrElse s.Parts.Display.Tag <> wp.Tag Then
                Throw New InvalidOperationException("Make the displayed top-level assembly the work part. An in-place work component is not supported.")
            End If
            If Not wp.IsFullyLoaded Then Throw New InvalidOperationException("Fully load the work part before running the journal.")
            Dim setup As New SetupForm()
            Using setup
                If setup.ShowDialog() <> Forms.DialogResult.OK Then Return
                Dim cfg As Settings = If(setup.ConfigPath.Length = 0, New Settings(), Settings.Load(setup.ConfigPath))
                cfg.Validate()
                runFolder = CreateRunFolder(setup.OutputFolder)
                WriteLog("NX 2306 EXTERIOR EXPORT | " & DateTime.Now.ToString("s"))
                WriteLog("NXOpen assembly version: " & GetType(NXObject).Assembly.GetName().Version.ToString())
                WriteLog("Target part: " & wp.Leaf & " | " & wp.FullPath)
                WriteLog("Run mode: " & setup.RunMode)
                WriteLog("Configuration: " & If(setup.ConfigPath.Length = 0, "Built-in defaults", setup.ConfigPath))
                WriteLog(cfg.Describe())
                WriteLog("Output folder: " & runFolder)
                WriteLog("Visibility means unblanked, unsuppressed, selected reference-set geometry and visible body layers; not screen occlusion.")

                If cfg.Source = "existing" Then
                    If setup.RunMode = "Inspect only" Then
                        WriteExistingInventory()
                        runStatus = "INSPECTED_EXISTING_BODIES"
                        Return
                    End If
                    Dim existing As List(Of Body) = ChooseExistingBodies()
                    If existing.Count = 0 Then
                        runStatus = "CANCELLED_NO_EXISTING_BODY_SELECTION"
                        Return
                    End If
                    notices.Add("Existing bodies are used unchanged. Associativity is not removed or asserted for existing geometry.")
                    runStatus = "EXISTING_GEOMETRY_REVIEWED"
                    GeometryReport(existing)
                    Dim existingProtected As HashSet(Of Tag) = SnapshotBodyTags()
                    For Each body As Body In existing
                        existingProtected.Remove(body.Tag)
                    Next
                    Dim approved As Boolean = IsolatedReview(cfg, existing, existingProtected, setup.RunMode = "Build, review and export")
                    If setup.RunMode = "Build, review and export" Then
                        If approved Then
                            PreflightExport(cfg)
                            ExportResults(cfg, existing)
                        Else
                            runStatus = "EXPORT_CANCELLED"
                        End If
                    End If
                    Return
                End If

                Dim root As Component = wp.ComponentAssembly.RootComponent
                Dim rootPath As String = Path.GetFileNameWithoutExtension(wp.Leaf)
                If root IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(root.Name) Then rootPath = root.Name
                If rootPath.IndexOf("/"c) >= 0 Then Throw New InvalidOperationException("Root component name contains '/'; rename the occurrence or use a simpler test assembly.")
                WriteLog("Canonical root path: " & rootPath)
                Dim rootRecord As New OccurrenceRecord(rootPath, Nothing, wp, "")
                rows.Add(rootRecord)
                If root IsNot Nothing Then
                    For Each child As Component In root.GetChildren()
                        Walk(child, rootPath, "")
                    Next
                End If
                ValidatePaths(cfg)
                Dim seen As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
                For Each row As OccurrenceRecord In rows
                    If Not seen.Add(row.OccurrencePath) Then
                        issues.Add("Ambiguous occurrence path: " & row.OccurrencePath)
                        Continue For
                    End If
                    EvaluateRecord(row, cfg)
                Next
                WriteInventory()
                WriteLog("Candidate bodies: " & candidates.Count.ToString())
                If setup.RunMode = "Inspect only" Then
                    runStatus = If(issues.Count = 0, "INSPECTED", "INSPECTED_WITH_ERRORS")
                    ReviewText("Assembly inspection", InventoryReview(cfg), "Close")
                    Return
                End If
                If issues.Count > 0 Then Throw New InvalidOperationException("Inspection found blocking errors. See inventory.csv and report.txt. Fix the listed load, scope or reference-set issues and run again.")
                If candidates.Count = 0 Then Throw New InvalidOperationException("No eligible solid/sheet bodies were found.")
                If Not wp.HasWriteAccess OrElse wp.IsReadOnly Then Throw New InvalidOperationException("The existing work part must be writable for exterior creation.")
                If setup.RunMode = "Build, review and export" Then PreflightExport(cfg)
                If Not ReviewText("Review before creating geometry", InventoryReview(cfg) & vbCrLf & "A named Undo mark will be created. Source body geometry is not edited; the work part is not saved.", "Create exterior") Then
                    runStatus = "BUILD_CANCELLED"
                    Return
                End If

                Dim protectedBodies As HashSet(Of Tag) = SnapshotBodyTags()
                outerMark = s.SetUndoMark(Session.MarkVisibility.Visible, "NX Exterior - unassociated result")
                markExists = True
                CreateExterior(cfg)
                Dim result As List(Of Body) = NewBodies(protectedBodies)
                If result.Count = 0 Then Throw New InvalidOperationException("NX did not create any exterior bodies.")
                uf.Modl.DeleteBodyParms(BodyTags(result))
                If cfg.Sew Then AttemptSew(cfg, protectedBodies)
                result = NewBodies(protectedBodies)
                If result.Count = 0 Then Throw New InvalidOperationException("No exterior bodies remain after preparation.")
                uf.Modl.DeleteBodyParms(BodyTags(result))
                Dim sequence As Integer = 0
                For Each body As Body In result
                    sequence += 1
                    body.SetName("NX_EXT_" & sequence.ToString("000"))
                    body.SetUserAttribute(ResultAttribute, -1, "v1", Update.Option.Now)
                    body.Unblank()
                Next
                GeometryReport(result)
                runStatus = "GEOMETRY_CREATED_NOT_SAVED"
                ' Past this point, recoverable export failures keep the result.
                markExists = False
                Dim exportApproved As Boolean = IsolatedReview(cfg, result, protectedBodies, setup.RunMode = "Build, review and export")
                If setup.RunMode = "Build, review and export" Then
                    If exportApproved Then
                        ExportResults(cfg, result)
                    Else
                        runStatus = "GEOMETRY_KEPT_EXPORT_CANCELLED"
                    End If
                End If
            End Using
        Catch ex As Exception
            If markExists Then
                Try
                    s.UndoToMark(outerMark, Nothing)
                    WriteLog("Geometry transaction rolled back to the named Undo mark.")
                Catch undoError As Exception
                    WriteLog("ROLLBACK FAILED: " & undoError.Message)
                End Try
            End If
            runStatus = "FAILED"
            issues.Add(ex.GetType().FullName & ": " & ex.Message)
            WriteLog("ERROR: " & ex.ToString())
            Forms.MessageBox.Show(ex.Message & vbCrLf & "See the NX Listing Window and report.txt.", "NX Exterior - stopped", Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Error)
        Finally
            FinishReport()
        End Try
    End Sub

    Private Sub Walk(comp As Component, parentPath As String, ancestorReason As String)
        Dim row As OccurrenceRecord = Nothing
        Try
            Dim name As String = If(String.IsNullOrWhiteSpace(comp.Name), comp.DisplayName, comp.Name)
            If name.IndexOf("/"c) >= 0 Then Throw New InvalidOperationException("Component name contains '/': " & name)
            Dim reason As String = ancestorReason
            If comp.IsSuppressed Then reason = "suppressed (self or ancestor)"
            If reason.Length = 0 AndAlso comp.ReferenceSet = comp.EmptyPartRefsetName Then reason = "empty reference set (self or ancestor)"
            ' Retain hidden state independently so visibleOnly=False can include it.
            Dim hidden As Boolean = comp.IsBlanked OrElse ancestorReason = "hidden (self or ancestor)"
            If reason.Length = 0 AndAlso hidden Then reason = "hidden (self or ancestor)"
            Dim proto As Part = Nothing
            If Not reason.StartsWith("suppressed", StringComparison.Ordinal) Then
                Try
                    proto = TryCast(comp.Prototype, Part)
                Catch
                    ' An unloaded prototype is diagnosed only if it is in scope.
                End Try
            End If
            row = New OccurrenceRecord(parentPath & "/" & name, comp, proto, reason)
            row.ReferenceSetName = comp.ReferenceSet
            rows.Add(row)
            If reason.StartsWith("suppressed", StringComparison.Ordinal) OrElse reason.StartsWith("empty reference set", StringComparison.Ordinal) Then Return
            Dim children() As Component = comp.GetChildren()
            row.ChildCount = children.Length
            For Each child As Component In children
                Walk(child, row.OccurrencePath, reason)
            Next
        Catch ex As Exception
            Dim at As String = If(row Is Nothing, parentPath, row.OccurrencePath)
            issues.Add("Assembly traversal at " & at & ": " & ex.Message)
        End Try
    End Sub

    Private Sub ValidatePaths(cfg As Settings)
        Dim allPaths As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
        For Each row As OccurrenceRecord In rows
            allPaths.Add(row.OccurrencePath)
        Next
        For Each value As String In cfg.Selections
            If Not allPaths.Contains(value) Then issues.Add("Selected occurrence path not found: " & value)
        Next
        If cfg.ExcludeInternal Then
            For Each value As String In cfg.ExcludedPaths
                If Not allPaths.Contains(value) Then issues.Add("Explicit exclusion path not found: " & value)
            Next
        End If
    End Sub

    Private Function WithinPath(value As String, parent As String) As Boolean
        Return value.Equals(parent, StringComparison.OrdinalIgnoreCase) OrElse value.StartsWith(parent & "/", StringComparison.OrdinalIgnoreCase)
    End Function

    Private Function InScope(row As OccurrenceRecord, cfg As Settings) As Boolean
        If cfg.Scope = "entire" Then Return True
        For Each pathValue As String In cfg.Selections
            If cfg.Scope = "components" AndAlso row.OccurrencePath.Equals(pathValue, StringComparison.OrdinalIgnoreCase) Then Return True
            If cfg.Scope = "subassembly" AndAlso WithinPath(row.OccurrencePath, pathValue) Then Return True
        Next
        Return False
    End Function

    Private Function ExclusionReason(row As OccurrenceRecord, cfg As Settings) As String
        If Not cfg.ExcludeInternal Then Return ""
        For Each pathValue As String In cfg.ExcludedPaths
            If WithinPath(row.OccurrencePath, pathValue) Then Return "explicit internal exclusion: " & pathValue
        Next
        ' An excluded assembly occurrence excludes its descendants as well.
        For Each ancestor As OccurrenceRecord In rows
            If WithinPath(row.OccurrencePath, ancestor.OccurrencePath) Then
                If Not ancestor.CategoryChecked Then
                    Dim categoryValue As String = ReadAttribute(ancestor.Comp, "EXTERIOR_INTERNAL_CATEGORY")
                    If categoryValue.Length = 0 Then categoryValue = ReadAttribute(ancestor.PrototypePart, "EXTERIOR_INTERNAL_CATEGORY")
                    If categoryValue.Length = 0 Then
                        Dim flag As String = ReadAttribute(ancestor.Comp, "EXTERIOR_INTERNAL")
                        If flag.Length = 0 Then flag = ReadAttribute(ancestor.PrototypePart, "EXTERIOR_INTERNAL")
                        If flag.Equals("true", StringComparison.OrdinalIgnoreCase) Then categoryValue = "other"
                    End If
                    ancestor.InternalCategory = categoryValue.ToLowerInvariant()
                    ancestor.CategoryChecked = True
                End If
                If cfg.Categories.Contains(ancestor.InternalCategory) Then Return "confirmed internal category " & ancestor.InternalCategory & " at " & ancestor.OccurrencePath
            End If
        Next
        Return ""
    End Function

    Private Function ReadAttribute(obj As NXObject, title As String) As String
        If obj Is Nothing Then Return ""
        Try
            If obj.HasUserAttribute(title, NXObject.AttributeType.String, -1) Then Return obj.GetStringUserAttribute(title, -1).Trim()
        Catch ex As Exception
            Throw New InvalidOperationException("Cannot inspect attribute " & title & " on tag " & obj.Tag.ToString(), ex)
        End Try
        Return ""
    End Function

    Private Sub EvaluateRecord(row As OccurrenceRecord, cfg As Settings)
        Try
            If Not InScope(row, cfg) Then
                row.Status = "EXCLUDED" : row.Reason = "outside assembly scope" : Return
            End If
            If row.InheritedReason.StartsWith("suppressed", StringComparison.Ordinal) Then
                row.Status = "EXCLUDED" : row.Reason = row.InheritedReason : Return
            End If
            If row.InheritedReason.StartsWith("empty reference set", StringComparison.Ordinal) Then
                row.Status = "EXCLUDED" : row.Reason = row.InheritedReason : Return
            End If
            If cfg.VisibleOnly AndAlso row.InheritedReason.StartsWith("hidden", StringComparison.Ordinal) Then
                row.Status = "EXCLUDED" : row.Reason = row.InheritedReason : Return
            End If
            Dim reason As String = ExclusionReason(row, cfg)
            If reason.Length > 0 Then
                row.Status = "EXCLUDED" : row.Reason = reason : Return
            End If
            Dim proto As Part = row.PrototypePart
            If proto Is Nothing OrElse Not proto.IsFullyLoaded Then Throw New InvalidOperationException("Prototype is unloaded, partially loaded or not a modeling part. Fully load the component.")
            For Each ancestor As OccurrenceRecord In rows
                If ancestor.Comp IsNot Nothing AndAlso ancestor.ChildCount > 0 AndAlso WithinPath(row.OccurrencePath, ancestor.OccurrencePath) Then
                    If ancestor.ReferenceSetName <> ancestor.Comp.EntirePartRefsetName AndAlso ancestor.ReferenceSetName <> ancestor.Comp.EmptyPartRefsetName Then
                        Throw New InvalidOperationException("Subassembly " & ancestor.OccurrencePath & " uses reference set '" & ancestor.ReferenceSetName & "'. Set that occurrence to Entire Part before running this version; custom assembly reference-set component membership is not inferred.")
                    End If
                End If
            Next
            Dim allowed As HashSet(Of Tag) = Nothing
            If row.Comp IsNot Nothing Then
                Dim refName As String = row.Comp.ReferenceSet
                row.ReferenceSetName = refName
                If refName = row.Comp.EmptyPartRefsetName Then
                    row.Status = "EXCLUDED" : row.Reason = "empty reference set" : Return
                End If
                If refName <> row.Comp.EntirePartRefsetName Then
                    If row.ChildCount > 0 Then
                        Throw New InvalidOperationException("A subassembly uses reference set '" & refName & "'. Set that occurrence to Entire Part before this version runs; component membership in custom assembly reference sets is not inferred.")
                    End If
                    allowed = New HashSet(Of Tag)()
                    Dim found As Boolean = False
                    For Each rs As ReferenceSet In proto.GetAllReferenceSets()
                        If rs.Name = refName Then
                            found = True
                            For Each member As NXObject In rs.AskMembersInReferenceSet()
                                allowed.Add(member.Tag)
                            Next
                        End If
                    Next
                    If Not found Then Throw New InvalidOperationException("Reference set was not resolved: " & refName)
                End If
            End If
            For Each body As Body In proto.Bodies
                Try
                    If ReadAttribute(body, ResultAttribute) = "v1" Then Continue For
                    If Not body.IsSolidBody AndAlso Not body.IsSheetBody Then Continue For
                    If allowed IsNot Nothing AndAlso Not allowed.Contains(body.Tag) Then Continue For
                    If cfg.VisibleOnly Then
                        If body.IsBlanked OrElse proto.Layers.GetState(body.Layer) = NXOpen.Layer.State.Hidden Then Continue For
                        If row.Comp IsNot Nothing Then
                            Dim occurrence As Body = TryCast(row.Comp.FindOccurrence(body), Body)
                            If occurrence Is Nothing Then Throw New InvalidOperationException("Body occurrence was not resolved for tag " & body.Tag.ToString())
                            If occurrence.IsBlanked Then Continue For
                        End If
                    End If
                    candidates.Add(New BodyRecord(body, row.Comp, row.OccurrencePath))
                    row.BodyCount += 1
                Catch ex As Exception
                    issues.Add(row.OccurrencePath & " / body " & body.Tag.ToString() & ": " & ex.Message)
                    row.Status = "ERROR"
                    row.Reason = "one or more body inspections failed"
                End Try
            Next
            If row.Status <> "ERROR" Then
                row.Status = If(row.BodyCount > 0, "INCLUDED", "CONTAINER_OR_EMPTY")
                row.Reason = If(row.BodyCount > 0, "eligible geometry", "no eligible local bodies; child occurrences evaluated separately")
            End If
        Catch ex As Exception
            row.Status = "ERROR" : row.Reason = ex.Message
            issues.Add(row.OccurrencePath & ": " & ex.Message)
        End Try
    End Sub

    Private Sub CreateExterior(cfg As Settings)
        Dim bodyTags As New List(Of Tag)()
        Dim xforms As New List(Of Tag)()
        Dim transformByOccurrence As New Dictionary(Of Tag, Tag)()
        For Each item As BodyRecord In candidates
            Dim transform As Tag = Tag.Null
            If item.Comp IsNot Nothing Then
                If Not transformByOccurrence.TryGetValue(item.Comp.Tag, transform) Then
                    uf.So.CreateXformAssyCtxt(wp.Tag, item.Comp.Tag, Tag.Null, transform)
                    transformByOccurrence.Add(item.Comp.Tag, transform)
                End If
            End If
            bodyTags.Add(item.Body.Tag) : xforms.Add(transform)
        Next
        Dim directions As Double(,) = DirectionVectors(cfg.Quality <> "standard")
        Dim chordMm As Double = If(cfg.Quality = "standard", ChordStandardMm, If(cfg.Quality = "fine", ChordFineMm, ChordVeryFineMm))
        Dim resolution As Integer = If(cfg.Quality = "standard", UFConstants.UF_LINKED_HL_RES_NORMAL, If(cfg.Quality = "fine", UFConstants.UF_LINKED_HL_RES_FINE, UFConstants.UF_LINKED_HL_RES_VERY_FINE))
        Dim numFaces As Integer = 0
        Dim faces() As Tag = Nothing
        Dim bodyIndex() As Integer = Nothing
        WriteLog("Identifying exterior: " & candidates.Count.ToString() & " bodies, " & directions.GetLength(0).ToString() & " view directions; chord tolerance " & chordMm.ToString(CultureInfo.InvariantCulture) & " mm.")
        uf.Modl.IdentifyExteriorUsingHl(bodyTags.Count, bodyTags.ToArray(), xforms.ToArray(), directions.GetLength(0), directions, ToPartUnits(chordMm), resolution, numFaces, faces, bodyIndex)
        If numFaces <= 0 OrElse faces Is Nothing OrElse bodyIndex Is Nothing Then Throw New InvalidOperationException("Exterior identification returned no faces.")
        If faces.Length <> numFaces OrElse bodyIndex.Length <> numFaces Then Throw New InvalidOperationException("Exterior face/index arrays have inconsistent lengths.")
        For Each index As Integer In bodyIndex
            If index < 0 OrElse index >= bodyTags.Count Then Throw New InvalidOperationException("Exterior identification returned an invalid candidate-body index.")
        Next
        Dim data As New UFModl.LinkedExt()
        data.num_bodies = bodyTags.Count : data.bodies = bodyTags.ToArray() : data.xforms = xforms.ToArray()
        data.num_faces = numFaces : data.faces = faces : data.xform_index = bodyIndex
        data.group_results = UFConstants.UF_LINKED_EXT_GROUP_NONE
        data.mass_props = False : data.delete_openings = cfg.CloseOpenings : data.at_timestamp = False
        Dim feature As Tag = Tag.Null
        uf.Modl.CreateLinkedExterior(data, feature)
        If feature = Tag.Null Then Throw New InvalidOperationException("CreateLinkedExterior returned no feature.")
        WriteLog("Identified exterior faces: " & numFaces.ToString() & "; linked exterior created, parameters will be removed.")
        If cfg.CloseOpenings Then notices.Add("Hole closure requested through linked-exterior delete_openings. It applies to qualifying interior edge loops, not all arbitrary gaps.")
        notices.Add("Exterior recognition is direction/resolution dependent. Inspect recesses, narrow gaps and fully enclosed cavities before customer release.")
    End Sub

    Private Function DirectionVectors(allDirections As Boolean) As Double(,)
        Dim vectors As New List(Of Double())()
        For x As Integer = -1 To 1
            For y As Integer = -1 To 1
                For z As Integer = -1 To 1
                    Dim n As Integer = Math.Abs(x) + Math.Abs(y) + Math.Abs(z)
                    If n = 0 OrElse (Not allDirections AndAlso n <> 1) Then Continue For
                    Dim length As Double = Math.Sqrt(CDbl(x * x + y * y + z * z))
                    vectors.Add(New Double() {x / length, y / length, z / length})
                Next
            Next
        Next
        Dim result(vectors.Count - 1, 2) As Double
        For i As Integer = 0 To vectors.Count - 1
            For j As Integer = 0 To 2
                result(i, j) = vectors(i)(j)
            Next
        Next
        Return result
    End Function

    Private Function ToPartUnits(mm As Double) As Double
        Return ScaleFromMm(mm, wp.PartUnits = BasePart.Units.Inches)
    End Function

    Private Function ScaleFromMm(mm As Double, inches As Boolean) As Double
        Return If(inches, mm / 25.4, mm)
    End Function

    Private Sub AttemptSew(cfg As Settings, protectedBodies As HashSet(Of Tag))
        Dim localMark As Session.UndoMarkId = s.SetUndoMark(Session.MarkVisibility.Invisible, "NX Exterior - sew attempt")
        Dim builder As SewBuilder = Nothing
        Try
            Dim sheets As List(Of Body) = NewBodies(protectedBodies)
            If sheets.Count = 0 Then Return
            builder = wp.Features.CreateSewBuilder(Nothing)
            builder.Type = SewBuilder.Types.Sheet
            builder.BodyPreference = If(cfg.AttemptSolid, SewBuilder.BodyPreferenceTypes.Solid, SewBuilder.BodyPreferenceTypes.Sheet)
            builder.Tolerance = ToPartUnits(SewToleranceMm)
            builder.OutputMultipleSheets = True
            builder.TargetBodies.Add(sheets(0))
            For i As Integer = 1 To sheets.Count - 1
                builder.ToolBodies.Add(sheets(i))
            Next
            builder.CommitFeature()
            WriteLog("Sew operation committed; actual bodies will be counted.")
        Catch ex As Exception
            If builder IsNot Nothing Then
                builder.Destroy() : builder = Nothing
            End If
            s.UndoToMark(localMark, Nothing)
            notices.Add("Sew/solid attempt failed; unassociated extracted sheets retained: " & ex.Message)
        Finally
            If builder IsNot Nothing Then builder.Destroy()
        End Try
    End Sub

    Private Function SnapshotBodyTags() As HashSet(Of Tag)
        Dim tags As New HashSet(Of Tag)()
        For Each body As Body In wp.Bodies
            tags.Add(body.Tag)
        Next
        Return tags
    End Function

    Private Function NewBodies(protectedBodies As HashSet(Of Tag)) As List(Of Body)
        Dim result As New List(Of Body)()
        For Each body As Body In wp.Bodies
            If Not protectedBodies.Contains(body.Tag) AndAlso Not body.IsOccurrence Then result.Add(body)
        Next
        Return result
    End Function

    Private Function BodyTags(bodies As List(Of Body)) As Tag()
        Dim tags As New List(Of Tag)()
        For Each body As Body In bodies
            tags.Add(body.Tag)
        Next
        Return tags.ToArray()
    End Function

    Private Sub GeometryReport(bodies As List(Of Body))
        Dim solids As Integer = 0, sheets As Integer = 0
        Dim table As New StringBuilder("tag,name,type,free_boundary_loops" & vbCrLf)
        For Each body As Body In bodies
            Dim kind As String = If(body.IsSolidBody, "solid", "sheet")
            If body.IsSolidBody Then solids += 1 Else sheets += 1
            Dim loops As String = "not_measured"
            If body.IsSheetBody Then
                Try
                    Dim count As Integer = 0
                    Dim edgeCounts() As Integer = Nothing
                    Dim edges() As Tag = Nothing
                    uf.Modl.AskBodyBoundaries(body.Tag, count, edgeCounts, edges)
                    loops = count.ToString()
                Catch ex As Exception
                    notices.Add("Boundary query failed for body " & body.Tag.ToString() & ": " & ex.Message)
                End Try
            End If
            table.AppendLine(Csv(body.Tag.ToString()) & "," & Csv(body.Name) & "," & kind & "," & Csv(loops))
        Next
        File.WriteAllText(Path.Combine(runFolder, "bodies.csv"), table.ToString(), New UTF8Encoding(False))
        WriteLog("RESULT: " & bodies.Count.ToString() & " bodies; " & solids.ToString() & " solids; " & sheets.ToString() & " sheets.")
        If bodies.Count <> 1 Then notices.Add("ENGINEERING REVIEW: result is not one body. No artificial bridges or bounding solids were created.")
        If sheets > 0 Then notices.Add("Sheet bodies remain. A closed solid volume is not established for those sheets.")
    End Sub

    Private Function IsolatedReview(cfg As Settings, result As List(Of Body), protectedBodies As HashSet(Of Tag), offerExport As Boolean) As Boolean
        Dim changed As New List(Of DisplayableObject)()
        Try
            If cfg.PreviewIsolation Then
                Dim root As Component = wp.ComponentAssembly.RootComponent
                If root IsNot Nothing Then
                    For Each child As Component In root.GetChildren()
                        HideForReview(child, changed)
                    Next
                End If
                For Each body As Body In wp.Bodies
                    If protectedBodies.Contains(body.Tag) Then HideForReview(body, changed)
                Next
            End If
            Return ReviewText("Exterior result - review before export", BuildReview(cfg, result), If(offerExport, "Export result", "Keep result in work part"))
        Finally
            Dim failures As Integer = 0
            For i As Integer = changed.Count - 1 To 0 Step -1
                Try
                    changed(i).Unblank()
                Catch ex As Exception
                    failures += 1 : issues.Add("Visibility restoration failed for " & changed(i).Tag.ToString() & ": " & ex.Message)
                End Try
            Next
            WriteLog("Source visibility restoration: " & If(failures = 0, "complete", "ERROR - see report"))
            If failures > 0 Then Throw New InvalidOperationException("Source visibility could not be fully restored. Export stopped; inspect the report and restore visibility in NX.")
        End Try
    End Function

    Private Sub HideForReview(obj As DisplayableObject, changed As List(Of DisplayableObject))
        If Not obj.IsBlanked Then
            changed.Add(obj)
            obj.Blank()
        End If
    End Sub

    Private Sub SetGeometryFilters(types As ObjectTypeSelector)
        types.Solids = True : types.Surfaces = True
        types.Curves = False : types.Annotations = False : types.PmiData = False
        types.Csys = False : types.Structures = False : types.Attributes = False
        types.ProductData = False : types.FacetBodies = False
    End Sub

    Private Sub SetSelection(selector As ObjectSelector, bodies As List(Of Body))
        selector.SelectionScope = ObjectSelector.Scope.SelectedObjects
        For Each body As Body In bodies
            selector.SelectionComp.Add(body)
        Next
    End Sub

    Private Function ParasolidVersion(cfg As Settings) As ParasolidExporter.ParasolidVersionOption
        If cfg.ParasolidVersion = "nx_native" Then Return ParasolidExporter.ParasolidVersionOption.Current
        Dim value As Double = Double.Parse(cfg.ParasolidVersion, CultureInfo.InvariantCulture)
        Dim code As String = CInt(Math.Round(value * 10.0)).ToString(CultureInfo.InvariantCulture)
        For Each name As String In [Enum].GetNames(GetType(ParasolidExporter.ParasolidVersionOption))
            If Regex.IsMatch(name, "^Ps" & code & "(?:Nx|Ug)", RegexOptions.IgnoreCase) Then
                Return CType([Enum].Parse(GetType(ParasolidExporter.ParasolidVersionOption), name), ParasolidExporter.ParasolidVersionOption)
            End If
        Next
        Throw New InvalidOperationException("Parasolid " & cfg.ParasolidVersion & " is not listed by this installed NX exporter. Choose a supported version or NX native.")
    End Function

    Private Sub PreflightExport(cfg As Settings)
        If cfg.Format <> "step" Then
            Dim version As ParasolidExporter.ParasolidVersionOption = ParasolidVersion(cfg)
            WriteLog("Installed Parasolid version option: " & version.ToString())
            If cfg.Encoding <> "text" Then
                Throw New NotSupportedException("Binary Parasolid is not enabled in this journal: the published exporter interface does not establish a verified encoding switch. Choose Text (.x_t) in the website. STEP and export-both with text Parasolid are supported.")
            End If
        End If
    End Sub

    Private Sub ExportResults(cfg As Settings, bodies As List(Of Body))
        Dim failures As Integer = 0, succeeded As Integer = 0
        If cfg.Format <> "parasolid" Then
            Dim filename As String = Path.Combine(runFolder, cfg.OutputBaseName & ".stp")
            Dim builder As StepCreator = Nothing
            Try
                If File.Exists(filename) Then Throw New IOException("Refusing to overwrite " & filename)
                builder = s.DexManager.CreateStepCreator()
                builder.ExportDestination = BaseCreator.ExportDestinationOption.NativeFileSystem
                builder.ExportFrom = StepCreator.ExportFromOption.DisplayPart
                builder.ExportAs = If(cfg.StepProtocol = "AP214", StepCreator.ExportAsOption.Ap214, StepCreator.ExportAsOption.Ap242)
                builder.FileSaveFlag = False
                builder.UserDefinedAttributes = False : builder.SystemAttributes = False
                builder.ProcessHoldFlag = True
                builder.ExportExtRef = False
                builder.OutputFile = filename
                SetGeometryFilters(builder.ObjectTypes)
                SetSelection(builder.ExportSelectionBlock, bodies)
                If cfg.StepSettingsFile.Length > 0 Then builder.SettingsFile = cfg.StepSettingsFile
                builder.Commit()
                CheckOutput(filename)
                succeeded += 1
                WriteLog("STEP " & cfg.StepProtocol & ": file created, " & New FileInfo(filename).Length.ToString() & " bytes | " & filename)
            Catch ex As Exception
                failures += 1 : issues.Add("STEP export: " & ex.Message)
                WriteLog("STEP FAILED: " & ex.Message)
            Finally
                If builder IsNot Nothing Then builder.Destroy()
            End Try
        End If
        If cfg.Format <> "step" Then
            Dim filename As String = Path.Combine(runFolder, cfg.OutputBaseName & ".x_t")
            Dim builder As ParasolidExporter = Nothing
            Try
                If File.Exists(filename) Then Throw New IOException("Refusing to overwrite " & filename)
                builder = s.DexManager.CreateParasolidExporter()
                builder.ExportDestination = BaseCreator.ExportDestinationOption.NativeFileSystem
                builder.ExportFrom = ParasolidExporter.ExportFromOption.DisplayedPart
                builder.ProcessHoldFlag = True
                builder.FlattenAssembly = True
                builder.ParasolidVersion = ParasolidVersion(cfg)
                builder.OutputFile = filename
                builder.OutputFileExtension = ".x_t"
                SetGeometryFilters(builder.ObjectTypes)
                SetSelection(builder.ExportSelectionBlock, bodies)
                builder.Commit()
                CheckOutput(filename)
                succeeded += 1
                WriteLog("PARASOLID text: file created, " & New FileInfo(filename).Length.ToString() & " bytes | " & filename)
            Catch ex As Exception
                failures += 1 : issues.Add("Parasolid export: " & ex.Message)
                WriteLog("PARASOLID FAILED: " & ex.Message)
            Finally
                If builder IsNot Nothing Then builder.Destroy()
            End Try
        End If
        runStatus = If(failures = 0, "EXPORT_FILES_CREATED", If(succeeded > 0, "PARTIAL_EXPORT", "EXPORT_FAILED"))
        WriteLog("File existence/size checked; geometry fidelity and recipient compatibility require reopening in the receiving CAD system.")
    End Sub

    Private Sub CheckOutput(filename As String)
        If Not File.Exists(filename) OrElse New FileInfo(filename).Length = 0 Then Throw New IOException("Translator did not create a nonempty output file: " & filename)
    End Sub

    Private Function CreateRunFolder(outputRoot As String) As String
        If Not Directory.Exists(outputRoot) Then Throw New DirectoryNotFoundException("Choose an existing output folder.")
        Dim folder As String = Path.Combine(Path.GetFullPath(outputRoot), "NX_Exterior_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & "_" & Guid.NewGuid().ToString("N").Substring(0, 8))
        Directory.CreateDirectory(folder)
        Return folder
    End Function

    Private Function Csv(value As String) As String
        Return """" & value.Replace("""", """""") & """"
    End Function

    Private Sub WriteInventory()
        Dim table As New StringBuilder("occurrence_path,status,body_count,reference_set,reason" & vbCrLf)
        For Each row As OccurrenceRecord In rows
            table.AppendLine(Csv(row.OccurrencePath) & "," & Csv(row.Status) & "," & row.BodyCount.ToString() & "," & Csv(row.ReferenceSetName) & "," & Csv(row.Reason))
            WriteLog(row.Status & " | " & row.OccurrencePath & " | bodies=" & row.BodyCount.ToString() & " | " & row.Reason)
        Next
        File.WriteAllText(Path.Combine(runFolder, "inventory.csv"), table.ToString(), New UTF8Encoding(False))
    End Sub

    Private Sub WriteExistingInventory()
        WriteLog("EXISTING BODY INVENTORY - bodies directly owned by the work part")
        For Each body As Body In wp.Bodies
            WriteLog("Tag=" & body.Tag.ToString() & " | " & body.Name & " | " & If(body.IsSolidBody, "solid", "sheet") & " | journal result=" & ReadAttribute(body, ResultAttribute))
        Next
    End Sub

    Private Function InventoryReview(cfg As Settings) As String
        Dim included As Integer = 0, excluded As Integer = 0, containers As Integer = 0
        For Each row As OccurrenceRecord In rows
            If row.Status = "INCLUDED" Then included += 1
            If row.Status = "EXCLUDED" Then excluded += 1
            If row.Status = "CONTAINER_OR_EMPTY" Then containers += 1
        Next
        Return cfg.Describe() & vbCrLf & vbCrLf & "Actual work part: " & wp.Leaf & vbCrLf &
            "Included body-bearing occurrences: " & included.ToString() & vbCrLf &
            "Excluded occurrences: " & excluded.ToString() & vbCrLf &
            "Containers / no eligible local bodies: " & containers.ToString() & vbCrLf &
            "Candidate bodies: " & candidates.Count.ToString() & vbCrLf &
            "Blocking inspection errors: " & issues.Count.ToString() & vbCrLf &
            "Output bodies: pending extraction; target = 1" & vbCrLf &
            "Output files: " & cfg.OutputBaseName & If(cfg.Format = "parasolid", "", ".stp") & If(cfg.Format = "both", " + " & cfg.OutputBaseName & ".x_t", If(cfg.Format = "parasolid", ".x_t", "")) & vbCrLf &
            "Report folder: " & runFolder & vbCrLf & vbCrLf &
            "Internal exclusion categories require confirmed attributes; exact paths are also supported. Unclassified parts are not excluded merely because their names look internal." & vbCrLf &
            "See inventory.csv for exact paths, counts and reasons." & vbCrLf & vbCrLf & String.Join(vbCrLf, issues.ToArray())
    End Function

    Private Function BuildReview(cfg As Settings, bodies As List(Of Body)) As String
        Dim solids As Integer = 0
        For Each body As Body In bodies
            If body.IsSolidBody Then solids += 1
        Next
        Return cfg.Describe() & vbCrLf & vbCrLf & "ACTUAL RESULT" & vbCrLf &
            "Bodies: " & bodies.Count.ToString() & " (target 1)" & vbCrLf &
            "Solids: " & solids.ToString() & "; sheets: " & (bodies.Count - solids).ToString() & vbCrLf &
            "Files: not exported yet" & vbCrLf & "Output folder: " & runFolder & vbCrLf & vbCrLf &
            String.Join(vbCrLf & vbCrLf, notices.ToArray()) & vbCrLf & vbCrLf &
            "Existing part has NOT been saved. Source component visibility is restored when this dialog closes. Use NX Undo to remove a newly created exterior if required."
    End Function

    Private Function ReviewText(title As String, text As String, acceptText As String) As Boolean
        Using form As New Forms.Form()
            form.Text = title : form.Size = New Drawing.Size(800, 650)
            form.StartPosition = Forms.FormStartPosition.CenterScreen
            Dim content As New Forms.TextBox()
            content.Multiline = True : content.ReadOnly = True : content.ScrollBars = Forms.ScrollBars.Both
            content.WordWrap = False : content.Dock = Forms.DockStyle.Fill
            content.Font = New Drawing.Font("Consolas", 10.0F) : content.Text = text
            Dim buttons As New Forms.FlowLayoutPanel()
            buttons.Dock = Forms.DockStyle.Bottom : buttons.Height = 50
            buttons.FlowDirection = Forms.FlowDirection.RightToLeft
            Dim accept As New Forms.Button()
            accept.Text = acceptText : accept.AutoSize = True : accept.Height = 32
            accept.DialogResult = Forms.DialogResult.OK
            Dim cancel As New Forms.Button()
            cancel.Text = "Cancel / close" : cancel.AutoSize = True : cancel.Height = 32
            cancel.DialogResult = Forms.DialogResult.Cancel
            buttons.Controls.Add(accept) : buttons.Controls.Add(cancel)
            form.Controls.Add(content) : form.Controls.Add(buttons)
            form.AcceptButton = accept : form.CancelButton = cancel
            Return form.ShowDialog() = Forms.DialogResult.OK
        End Using
    End Function

    Private Function ChooseExistingBodies() As List(Of Body)
        Dim available As New List(Of Body)()
        For Each body As Body In wp.Bodies
            If Not body.IsOccurrence Then available.Add(body)
        Next
        Dim result As New List(Of Body)()
        Using form As New Forms.Form()
            form.Text = "Select existing exterior bodies owned by the work part"
            form.Size = New Drawing.Size(720, 450) : form.StartPosition = Forms.FormStartPosition.CenterScreen
            Dim list As New Forms.CheckedListBox()
            list.Dock = Forms.DockStyle.Fill : list.CheckOnClick = True
            For Each body As Body In available
                list.Items.Add(body.Name & " | tag " & body.Tag.ToString() & " | " & If(body.IsSolidBody, "solid", "sheet"), ReadAttribute(body, ResultAttribute) = "v1")
            Next
            Dim accept As New Forms.Button()
            accept.Dock = Forms.DockStyle.Bottom : accept.Height = 40
            accept.Text = "Use checked bodies" : accept.DialogResult = Forms.DialogResult.OK
            form.Controls.Add(list) : form.Controls.Add(accept)
            If form.ShowDialog() = Forms.DialogResult.OK Then
                For Each checkedIndex As Object In list.CheckedIndices
                    result.Add(available(CInt(checkedIndex)))
                Next
            End If
        End Using
        Return result
    End Function

    Private Sub WriteLog(value As String)
        log.Add(value)
        s.ListingWindow.WriteLine(value)
    End Sub

    Private Sub RunPureSelfChecks()
        Dim defaults As New Settings()
        defaults.Validate()
        Check(DirectionVectors(False).GetLength(0) = 6, "axial direction count")
        Dim fineDirections As Double(,) = DirectionVectors(True)
        Check(fineDirections.GetLength(0) = 26, "fine direction count")
        For i As Integer = 0 To fineDirections.GetLength(0) - 1
            Dim lengthSquared As Double = 0.0
            For j As Integer = 0 To 2
                lengthSquared += fineDirections(i, j) * fineDirections(i, j)
            Next
            Check(Math.Abs(lengthSquared - 1.0) < 0.0000001, "normalized view direction")
        Next
        Check(WithinPath("ROOT/A/B", "ROOT/A"), "descendant scope")
        Check(WithinPath("root/a", "ROOT/A"), "case-insensitive exact scope")
        Check(Not WithinPath("ROOT/AB", "ROOT/A"), "scope path boundary")
        Check(Math.Abs(ScaleFromMm(25.4, True) - 1.0) < 0.0000001, "inch tolerance conversion")
        Check(ScaleFromMm(0.03, False) = 0.03, "millimeter tolerance conversion")
        Check(Csv("a,b") = ChrW(34) & "a,b" & ChrW(34), "CSV comma quoting")
        Check(Csv("a" & ChrW(34) & "b") = ChrW(34) & "a" & ChrW(34) & ChrW(34) & "b" & ChrW(34), "CSV embedded quote escaping")
        Dim badName As New Settings()
        badName.OutputBaseName = "../wrong"
        MustReject(badName, "invalid output filename")
        Dim reservedName As New Settings()
        reservedName.OutputBaseName = "CON"
        MustReject(reservedName, "Windows reserved output filename")
        Dim badScope As New Settings()
        badScope.Scope = "subassembly"
        MustReject(badScope, "missing selected occurrence")
        Dim badSolid As New Settings()
        badSolid.Mode = "solid" : badSolid.Sew = False
        MustReject(badSolid, "solid prerequisites")
        WriteLog("Startup pure-logic self-checks passed. NX geometry/export operations still require local runtime validation.")
    End Sub

    Private Sub Check(condition As Boolean, label As String)
        If Not condition Then Throw New InvalidOperationException("Journal self-check failed: " & label)
    End Sub

    Private Sub MustReject(value As Settings, label As String)
        Dim rejected As Boolean = False
        Try
            value.Validate()
        Catch ex As InvalidDataException
            rejected = True
        End Try
        Check(rejected, label)
    End Sub

    Private Sub FinishReport()
        If s Is Nothing Then Return
        Try
            WriteLog("") : WriteLog("FINAL STATUS: " & runStatus)
            For Each item As String In notices
                WriteLog("WARNING / REVIEW: " & item)
            Next
            For Each item As String In issues
                WriteLog("ERROR: " & item)
            Next
            WriteLog("Warnings: " & notices.Count.ToString() & "; errors: " & issues.Count.ToString())
            If runFolder.Length > 0 Then
                WriteLog("Report: " & Path.Combine(runFolder, "report.txt"))
                File.WriteAllText(Path.Combine(runFolder, "report.txt"), String.Join(vbCrLf, log.ToArray()), New UTF8Encoding(False))
            End If
        Catch ex As Exception
            s.ListingWindow.WriteLine("Could not write final report: " & ex.Message)
        End Try
    End Sub

    Public Function GetUnloadOption(dummy As String) As Integer
        Return CInt(Session.LibraryUnloadOption.Immediately)
    End Function

    Private Class OccurrenceRecord
        Public OccurrencePath As String
        Public Comp As Component
        Public PrototypePart As Part
        Public InheritedReason As String
        Public Status As String = "NOT_EVALUATED"
        Public Reason As String = ""
        Public ReferenceSetName As String = "work part"
        Public BodyCount As Integer = 0
        Public ChildCount As Integer = 0
        Public CategoryChecked As Boolean = False
        Public InternalCategory As String = ""
        Public Sub New(pathValue As String, component As Component, proto As Part, inherited As String)
            OccurrencePath = pathValue : Comp = component : PrototypePart = proto : InheritedReason = inherited
        End Sub
    End Class

    Private Class BodyRecord
        Public Body As Body
        Public Comp As Component
        Public OccurrencePath As String
        Public Sub New(value As Body, component As Component, pathValue As String)
            Body = value : Comp = component : OccurrencePath = pathValue
        End Sub
    End Class

    Private Class Settings
        Public ReferenceLabel As String = "current work part"
        Public Scope As String = "entire"
        Public Selections As New List(Of String)()
        Public VisibleOnly As Boolean = True
        Public ExcludeInternal As Boolean = True
        Public Categories As New HashSet(Of String)(New String() {"gears", "bearings", "seals", "other"}, StringComparer.OrdinalIgnoreCase)
        Public ExcludedPaths As New List(Of String)()
        Public Source As String = "extract"
        Public Mode As String = "surface"
        Public Quality As String = "fine"
        Public CloseOpenings As Boolean = True
        Public Sew As Boolean = True
        Public AttemptSolid As Boolean = False
        Public PreviewIsolation As Boolean = True
        Public Format As String = "both"
        Public OutputBaseName As String = "assembly_exterior"
        Public StepProtocol As String = "AP242"
        Public ParasolidVersion As String = "nx_native"
        Public Encoding As String = "text"
        Public StepSettingsFile As String = ""

        Public Shared Function Load(filename As String) As Settings
            If Not File.Exists(filename) Then Throw New FileNotFoundException("Configuration JSON was not found.", filename)
            Dim text As String = File.ReadAllText(filename, EncodingUTF8())
            If text.Length > 4000000 Then Throw New InvalidDataException("Configuration is too large.")
            Dim assembly As Assembly = System.Reflection.Assembly.Load("System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35")
            Dim serializerType As Type = assembly.GetType("System.Web.Script.Serialization.JavaScriptSerializer", True)
            Dim serializer As Object = Activator.CreateInstance(serializerType)
            Dim parsed As Object = serializerType.GetMethod("DeserializeObject").Invoke(serializer, New Object() {text})
            Dim root As IDictionary(Of String, Object) = Obj(parsed, "configuration")
            If Str(root, "schema") <> "nx2306.exterior-export.configuration.v1" Then Throw New InvalidDataException("Unsupported configuration schema. Download the JSON from the Exterior website.")
            If Str(root, "nxRelease") <> "2306" Then Throw New InvalidDataException("The configuration must target NX 2306.")
            Dim workflow As IDictionary(Of String, Object) = Obj(Required(root, "workflow"), "workflow")
            If Str(workflow, "destination") <> "existing_part" OrElse Bool(workflow, "associativity") Then Throw New InvalidDataException("Only existing-part, unassociated extraction is supported.")
            Dim assemblyOptions As IDictionary(Of String, Object) = Obj(Required(root, "assembly"), "assembly")
            Dim exclusions As IDictionary(Of String, Object) = Obj(Required(assemblyOptions, "exclusions"), "assembly.exclusions")
            Dim geometry As IDictionary(Of String, Object) = Obj(Required(root, "geometry"), "geometry")
            Dim exportOptions As IDictionary(Of String, Object) = Obj(Required(root, "export"), "export")
            Dim result As New Settings()
            result.ReferenceLabel = Str(assemblyOptions, "reference")
            result.Scope = Str(assemblyOptions, "scope")
            result.Selections = Strings(Required(assemblyOptions, "selectedOccurrencePaths"))
            result.VisibleOnly = Bool(assemblyOptions, "visibleOnly")
            result.ExcludeInternal = Bool(exclusions, "enabled")
            result.Categories = New HashSet(Of String)(Strings(Required(exclusions, "categories")), StringComparer.OrdinalIgnoreCase)
            result.ExcludedPaths = Strings(Required(exclusions, "explicitOccurrencePaths"))
            result.Source = Str(geometry, "source") : result.Mode = Str(geometry, "mode")
            result.Quality = If(result.Source = "existing", "fine", Str(geometry, "quality"))
            result.CloseOpenings = Bool(geometry, "closeOpenings") : result.Sew = Bool(geometry, "sewSurfaces")
            result.AttemptSolid = Bool(geometry, "attemptSolidWhenClosed") : result.PreviewIsolation = Bool(geometry, "previewIsolation")
            result.Format = Str(exportOptions, "format") : result.OutputBaseName = Str(exportOptions, "outputBaseName")
            If result.Format <> "parasolid" Then result.StepProtocol = Str(exportOptions, "stepProtocol")
            If result.Format <> "step" Then
                Dim parasolid As IDictionary(Of String, Object) = Obj(Required(exportOptions, "parasolid"), "export.parasolid")
                result.ParasolidVersion = Str(parasolid, "version") : result.Encoding = Str(parasolid, "encoding")
            End If
            If exportOptions.ContainsKey("stepSettingsFile") Then result.StepSettingsFile = Str(exportOptions, "stepSettingsFile")
            Return result
        End Function

        Public Sub Validate()
            Choice(Scope, New String() {"entire", "subassembly", "components"}, "assembly scope")
            Choice(Source, New String() {"extract", "existing"}, "exterior source")
            Choice(Mode, New String() {"surface", "solid", "existing"}, "geometry mode")
            Choice(Quality, New String() {"standard", "fine", "very_fine"}, "quality")
            Choice(Format, New String() {"step", "parasolid", "both"}, "export format")
            Choice(StepProtocol, New String() {"AP214", "AP242"}, "STEP protocol")
            Choice(Encoding, New String() {"text", "binary"}, "Parasolid encoding")
            If Source = "extract" AndAlso Mode = "existing" Then Throw New InvalidDataException("Extract mode cannot use existing geometry mode.")
            If Scope <> "entire" AndAlso Selections.Count = 0 Then Throw New InvalidDataException("Selected scope requires occurrence paths.")
            If Scope = "subassembly" AndAlso Selections.Count <> 1 Then Throw New InvalidDataException("Select exactly one subassembly path.")
            If Not Regex.IsMatch(OutputBaseName, "^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$") OrElse Regex.IsMatch(OutputBaseName, "^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$", RegexOptions.IgnoreCase) Then Throw New InvalidDataException("Invalid or reserved Windows output base name.")
            If ParasolidVersion <> "nx_native" AndAlso Not Regex.IsMatch(ParasolidVersion, "^\d{1,2}(\.\d)?$") Then Throw New InvalidDataException("Parasolid version must be nx_native or a supported number with at most one decimal place.")
            For Each value As String In Categories
                Choice(value.ToLowerInvariant(), New String() {"gears", "bearings", "fasteners", "seals", "other"}, "internal category")
            Next
            For Each list As List(Of String) In New List(Of String)() {Selections, ExcludedPaths}
                For Each value As String In list
                    If value.Length = 0 OrElse value.StartsWith("/") OrElse value.EndsWith("/") OrElse value.Contains("//") OrElse value.Contains("\") Then Throw New InvalidDataException("Occurrence paths must be exact inventory paths with '/' separators.")
                Next
            Next
            If Source = "extract" AndAlso Mode = "solid" AndAlso (Not Sew OrElse Not AttemptSolid) Then Throw New InvalidDataException("Solid mode requires sewing and conditional solid creation.")
            If Source = "extract" AndAlso AttemptSolid AndAlso Not Sew Then Throw New InvalidDataException("Solid creation requires sewing.")
            If StepSettingsFile.Length > 0 AndAlso Not File.Exists(StepSettingsFile) Then Throw New FileNotFoundException("STEP settings file was not found.", StepSettingsFile)
        End Sub

        Public Function Describe() As String
            Return "Configuration assembly reference (label): " & ReferenceLabel & vbCrLf &
                "Scope: " & Scope & "; visible only: " & VisibleOnly.ToString() & vbCrLf &
                "Source: " & Source & "; mode: " & Mode & "; quality: " & If(Source = "existing", "not applied", Quality) & vbCrLf &
                "Close openings: " & CloseOpenings.ToString() & "; sew: " & Sew.ToString() & "; conditional solid: " & AttemptSolid.ToString() & vbCrLf &
                "Internal exclusions enabled: " & ExcludeInternal.ToString() & "; categories: " & String.Join(",", New List(Of String)(Categories).ToArray()) & vbCrLf &
                "Format: " & Format & "; STEP: " & StepProtocol & "; Parasolid: " & ParasolidVersion & " / " & Encoding & vbCrLf &
                "Destination: existing work part; extraction unassociated; target body count: 1."
        End Function

        Private Shared Function EncodingUTF8() As System.Text.Encoding
            Return New UTF8Encoding(False, True)
        End Function
        Private Shared Function Required(obj As IDictionary(Of String, Object), key As String) As Object
            If Not obj.ContainsKey(key) Then Throw New InvalidDataException("Missing configuration field: " & key)
            Return obj(key)
        End Function
        Private Shared Function Obj(value As Object, label As String) As IDictionary(Of String, Object)
            Dim result As IDictionary(Of String, Object) = TryCast(value, IDictionary(Of String, Object))
            If result Is Nothing Then Throw New InvalidDataException(label & " must be a JSON object.")
            Return result
        End Function
        Private Shared Function Str(obj As IDictionary(Of String, Object), key As String) As String
            Dim value As String = TryCast(Required(obj, key), String)
            If value Is Nothing Then Throw New InvalidDataException(key & " must be a string.")
            Return value.Trim()
        End Function
        Private Shared Function Bool(obj As IDictionary(Of String, Object), key As String) As Boolean
            Dim value As Object = Required(obj, key)
            If Not TypeOf value Is Boolean Then Throw New InvalidDataException(key & " must be a Boolean.")
            Return CBool(value)
        End Function
        Private Shared Function Strings(value As Object) As List(Of String)
            If value Is Nothing OrElse TypeOf value Is String OrElse Not TypeOf value Is IEnumerable Then Throw New InvalidDataException("Expected a JSON string array.")
            Dim result As New List(Of String)()
            For Each item As Object In DirectCast(value, IEnumerable)
                If Not TypeOf item Is String Then Throw New InvalidDataException("Expected strings in configuration array.")
                result.Add(DirectCast(item, String).Trim())
            Next
            Return result
        End Function
        Private Shared Sub Choice(value As String, options() As String, label As String)
            If Array.IndexOf(options, value) < 0 Then Throw New InvalidDataException("Invalid " & label & ": " & value)
        End Sub
    End Class

    Private Class SetupForm
        Inherits Forms.Form
        Private config As New Forms.TextBox()
        Private output As New Forms.TextBox()
        Private mode As New Forms.ComboBox()
        Public ReadOnly Property ConfigPath As String
            Get
                Return config.Text.Trim()
            End Get
        End Property
        Public ReadOnly Property OutputFolder As String
            Get
                Return output.Text.Trim()
            End Get
        End Property
        Public ReadOnly Property RunMode As String
            Get
                Return CStr(mode.SelectedItem)
            End Get
        End Property
        Public Sub New()
            Text = "NX 2306 - Exterior export journal"
            ClientSize = New Drawing.Size(680, 325)
            StartPosition = Forms.FormStartPosition.CenterScreen
            FormBorderStyle = Forms.FormBorderStyle.FixedDialog
            MaximizeBox = False : MinimizeBox = False
            Dim title As New Forms.Label()
            title.Text = "Create an unassociated exterior in the existing work part."
            title.SetBounds(18, 15, 640, 24)
            Controls.Add(title)
            AddLabel("Website configuration JSON (optional; blank uses defaults)", 18, 50)
            config.SetBounds(18, 74, 540, 25)
            Dim pickConfig As New Forms.Button()
            pickConfig.Text = "Browse..." : pickConfig.SetBounds(570, 72, 90, 28)
            AddHandler pickConfig.Click, AddressOf BrowseConfig
            AddLabel("Output folder (a separate run folder will be created)", 18, 112)
            output.Text = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            output.SetBounds(18, 136, 540, 25)
            Dim pickOutput As New Forms.Button()
            pickOutput.Text = "Browse..." : pickOutput.SetBounds(570, 134, 90, 28)
            AddHandler pickOutput.Click, AddressOf BrowseOutput
            AddLabel("Run mode", 18, 176)
            mode.SetBounds(18, 200, 360, 27) : mode.DropDownStyle = Forms.ComboBoxStyle.DropDownList
            mode.Items.AddRange(New Object() {"Inspect only", "Build and review", "Build, review and export"})
            mode.SelectedIndex = 0
            Dim hint As New Forms.Label()
            hint.Text = "First run: Inspect only. Load all geometry. No part is saved automatically."
            hint.SetBounds(18, 240, 640, 24)
            Dim run As New Forms.Button()
            run.Text = "Continue" : run.SetBounds(450, 280, 100, 30) : run.DialogResult = Forms.DialogResult.OK
            Dim cancel As New Forms.Button()
            cancel.Text = "Cancel" : cancel.SetBounds(560, 280, 100, 30) : cancel.DialogResult = Forms.DialogResult.Cancel
            Controls.AddRange(New Forms.Control() {config, output, mode, pickConfig, pickOutput, hint, run, cancel})
            AcceptButton = run : CancelButton = cancel
        End Sub
        Private Sub AddLabel(value As String, x As Integer, y As Integer)
            Dim label As New Forms.Label()
            label.Text = value : label.SetBounds(x, y, 640, 22) : Controls.Add(label)
        End Sub
        Private Sub BrowseConfig(sender As Object, e As EventArgs)
            Using dialog As New Forms.OpenFileDialog()
                dialog.Filter = "JSON configuration (*.json)|*.json|All files (*.*)|*.*"
                If dialog.ShowDialog() = Forms.DialogResult.OK Then config.Text = dialog.FileName
            End Using
        End Sub
        Private Sub BrowseOutput(sender As Object, e As EventArgs)
            Using dialog As New Forms.FolderBrowserDialog()
                dialog.Description = "Choose the folder for CAD exports and reports"
                dialog.SelectedPath = output.Text
                If dialog.ShowDialog() = Forms.DialogResult.OK Then output.Text = dialog.SelectedPath
            End Using
        End Sub
    End Class
End Module
