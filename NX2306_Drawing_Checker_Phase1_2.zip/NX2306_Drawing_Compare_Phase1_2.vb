' NX 2306 Drafting Audit & Native Drawing Comparison — engineering prototype
' Phase 1: data extraction; Phase 2: cautious native .prt comparison.
' SAFETY: No source part saves, view updates, object changes, or permanent colors.
' Verify in a TEST COPY in a licensed NX 2306 installation before production use.
' NXOpen.dll, NXOpen.UF.dll, NXOpen.Utilities.dll + .NET WinForms.
' Excel COM late binding: Excel installed for XLSX, CSV fallback otherwise.
Option Strict Off
Option Explicit On

Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Windows.Forms
Imports NXOpen
Imports NXOpen.UF
Imports NXOpen.Utilities
Imports NXOpen.Drawings

Module NX2306_Drawing_Compare_Phase1_2
    Private ReadOnly s As Session = Session.GetSession()
    Private ReadOnly uf As UFSession = UFSession.GetUFSession()
    Private ReadOnly ci As CultureInfo = CultureInfo.InvariantCulture
    Private ReadOnly logs As New List(Of String)()

    Private Class Item
        Public Category As String = ""
        Public Kind As String = ""
        Public Sheet As String = ""
        Public Content As String = ""
        Public RawText As String = ""
        Public Detail As String = ""
        Public Nominal As Double = Double.NaN
        Public Upper As Double = Double.NaN
        Public Lower As Double = Double.NaN
        Public TolType As String = ""
        Public X As Double
        Public Y As Double
        Public Z As Double
        Public Located As Boolean
        Public SourceTag As Tag = Tag.Null
        Public Used As Boolean
        Public Ambiguous As Boolean
        Public ExtractionOk As Boolean = True
    End Class

    Private Class Snapshot
        Public FileName As String = ""
        Public Sheets As New List(Of Item)()
        Public Items As New List(Of Item)()
        Public Issues As New List(Of String)()
        Public Units As String = ""
    End Class

    Private Class Finding
        Public Id As String = ""
        Public Category As String = ""
        Public Sheet As String = ""
        Public Reference As String = ""
        Public Current As String = ""
        Public Status As String = ""
        Public Reason As String = ""
        Public CurrentTag As Tag = Tag.Null
    End Class

    Private Class Config
        Public RefFile As String = ""
        Public OutFile As String = ""
        Public Compare As Boolean = True
        Public MatchDistanceMm As Double = 15.0
        Public Dims As Boolean = True
        Public Notes As Boolean = True
        Public Gdt As Boolean = True
        Public Datums As Boolean = True
        Public Views As Boolean = True
        Public Excel As Boolean = True
        Public Capture As Boolean = True
        Public Review As Boolean = True
    End Class

    Public Sub Main(ByVal args() As String)
        Dim lw As ListingWindow = s.ListingWindow
        lw.Open()
        Dim cfg As Config = Nothing
        Try
            Dim currentPart As Part = s.Parts.Display
            If currentPart Is Nothing Then Throw New Exception("No displayed NX part.")
            If currentPart.DraftingDrawingSheets.ToArray().Length = 0 Then
                Throw New Exception("Displayed part has no drafting sheets.")
            End If
            cfg = AskConfig(currentPart)
            If cfg Is Nothing Then
                lw.WriteLine("User cancelled.")
                Return
            End If
            lw.WriteLine("NX DRAWING CHECKER (Phase 1/2) : " & DateTime.Now.ToString("s"))
            lw.WriteLine("Current = " & currentPart.FullPath)
            Dim cur As Snapshot = Extract(currentPart, cfg)
            Dim refSnap As Snapshot = Nothing
            If cfg.Compare Then
                If Not String.IsNullOrEmpty(currentPart.FullPath) AndAlso String.Equals(Path.GetFullPath(cfg.RefFile), Path.GetFullPath(currentPart.FullPath), StringComparison.OrdinalIgnoreCase) Then
                    Throw New Exception("Reference file and displayed drawing must be different files.")
                End If
                Dim loadStatus As PartLoadStatus = Nothing
                Dim refPart As Part = Nothing
                Try
                    refPart = TryCast(s.Parts.OpenBase(cfg.RefFile, loadStatus), Part)
                    If refPart Is Nothing Then Throw New Exception("Reference file did not load as an NX Part.")
                    If loadStatus IsNot Nothing AndAlso loadStatus.NumberUnloadedParts > 0 Then
                        cur.Issues.Add("Reference loading: " & loadStatus.NumberUnloadedParts.ToString() & " unloaded part(s) reported.")
                    End If
                    refSnap = Extract(refPart, cfg)
                Finally
                    If loadStatus IsNot Nothing Then loadStatus.Dispose()
                    ' Do NOT close a reference part; it may have already been open in the user's session.
                End Try
            End If
            Dim findings As List(Of Finding) = Audit(cur, refSnap, cfg)
            For Each f As Finding In findings
                If f.Status <> "PASS" Then
                    lw.WriteLine(f.Id & " " & f.Status.PadRight(11) & " " & f.Category.PadRight(10) & " " & f.Sheet & " : " & f.Reason)
                End If
            Next
            For Each issue As String In cur.Issues
                lw.WriteLine("CURRENT WARNING: " & issue)
            Next
            If refSnap IsNot Nothing Then
                For Each issue As String In refSnap.Issues
                    lw.WriteLine("REFERENCE WARNING: " & issue)
                Next
            End If
            ExportReport(cfg, cur, refSnap, findings)
            If cfg.Review Then ReviewFindings(findings)
            Dim failed As Integer = 0
            Dim uncertain As Integer = 0
            For Each f As Finding In findings
                If f.Status = "FAIL" OrElse f.Status = "MISSING" OrElse f.Status = "EXTRA" Then failed += 1
                If f.Status = "UNVERIFIED" OrElse f.Status = "ERROR" Then uncertain += 1
            Next
            lw.WriteLine("Complete. Findings=" & findings.Count & ", mismatches=" & failed & ", unverified/errors=" & uncertain)
            lw.WriteLine("No NX part was saved. Original display part remains displayed.")
        Catch ex As Exception
            lw.WriteLine("ERROR: " & ex.ToString())
            MessageBox.Show(ex.Message, "NX Drawing Checker", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function AskConfig(p As Part) As Config
        Dim c As New Config()
        Using d As New Form()
            d.Text = "NX 2306 Drawing Checker - Phase 1/2"
            d.FormBorderStyle = FormBorderStyle.FixedDialog
            d.StartPosition = FormStartPosition.CenterScreen
            d.Width = 645 : d.Height = 510
            d.MaximizeBox = False : d.MinimizeBox = False
            Dim lbl As New Label() With {.Text = "Reference .prt (leave blank for extraction only):", .Left = 15, .Top = 17, .Width = 400}
            d.Controls.Add(lbl)
            Dim refBox As New TextBox() With {.Left = 15, .Top = 40, .Width = 505}
            d.Controls.Add(refBox)
            Dim browseRef As New Button() With {.Text = "Browse...", .Left = 529, .Top = 38, .Width = 86}
            AddHandler browseRef.Click, Sub(sender, e)
                                            Using od As New OpenFileDialog()
                                                od.Filter = "NX Part (*.prt)|*.prt"
                                                If od.ShowDialog(d) = DialogResult.OK Then refBox.Text = od.FileName
                                            End Using
                                        End Sub
            d.Controls.Add(browseRef)
            d.Controls.Add(New Label() With {.Text = "Output .xlsx (CSV files created if Excel is unavailable):", .Left = 15, .Top = 82, .Width = 480})
            Dim outBox As New TextBox() With {.Left = 15, .Top = 107, .Width = 505, .Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "NX_Drawing_Audit.xlsx")}
            d.Controls.Add(outBox)
            Dim browseOut As New Button() With {.Text = "Save as...", .Left = 529, .Top = 105, .Width = 86}
            AddHandler browseOut.Click, Sub(sender, e)
                                            Using sd As New SaveFileDialog()
                                                sd.Filter = "Excel workbook (*.xlsx)|*.xlsx"
                                                sd.FileName = Path.GetFileName(outBox.Text)
                                                If sd.ShowDialog(d) = DialogResult.OK Then outBox.Text = sd.FileName
                                            End Using
                                        End Sub
            d.Controls.Add(browseOut)
            d.Controls.Add(New Label() With {.Text = "Maximum annotation anchor distance for cautious pairing (mm):", .Left = 15, .Top = 149, .Width = 460})
            Dim dist As New NumericUpDown() With {.Left = 490, .Top = 146, .Width = 120, .DecimalPlaces = 1, .Minimum = 1, .Maximum = 1000, .Value = 15}
            d.Controls.Add(dist)
            Dim cd As New CheckBox() With {.Text = "Dimensions and tolerances", .Checked = True, .Left = 15, .Top = 188, .Width = 260}
            Dim cn As New CheckBox() With {.Text = "Notes and labels", .Checked = True, .Left = 310, .Top = 188, .Width = 260}
            Dim cg As New CheckBox() With {.Text = "GD&T text frames (textual only)", .Checked = True, .Left = 15, .Top = 226, .Width = 280}
            Dim ct As New CheckBox() With {.Text = "Datum symbols (textual only)", .Checked = True, .Left = 310, .Top = 226, .Width = 300}
            Dim cv As New CheckBox() With {.Text = "Drawing sheets and views", .Checked = True, .Left = 15, .Top = 264, .Width = 280}
            Dim ce As New CheckBox() With {.Text = "Attempt Excel .xlsx output", .Checked = True, .Left = 310, .Top = 264, .Width = 280}
            Dim cp As New CheckBox() With {.Text = "Capture current NX graphics view", .Checked = True, .Left = 15, .Top = 300, .Width = 290}
            Dim ch As New CheckBox() With {.Text = "Review findings with temporary highlight", .Checked = True, .Left = 310, .Top = 300, .Width = 310}
            d.Controls.AddRange(New Control(){cd, cn, cg, ct, cv, ce, cp, ch})
            d.Controls.Add(New Label() With {.Text = "Limited scope: native .prt only; no full ASME/ISO compliance or pixel comparison.", .Left = 15, .Top = 343, .Width = 595, .Height = 30})
            Dim ok As New Button() With {.Text = "Extract / Compare", .Left = 362, .Top = 390, .Width = 135, .DialogResult = DialogResult.OK}
            Dim cancel As New Button() With {.Text = "Cancel", .Left = 517, .Top = 390, .Width = 93, .DialogResult = DialogResult.Cancel}
            d.Controls.AddRange(New Control(){ok, cancel})
            d.AcceptButton = ok : d.CancelButton = cancel
            If d.ShowDialog() <> DialogResult.OK Then Return Nothing
            If String.IsNullOrWhiteSpace(outBox.Text) Then Throw New Exception("Choose output path.")
            c.RefFile = refBox.Text.Trim()
            c.Compare = c.RefFile.Length > 0
            If c.Compare AndAlso Not File.Exists(c.RefFile) Then Throw New FileNotFoundException("Reference file not found", c.RefFile)
            c.OutFile = outBox.Text.Trim()
            If Not String.Equals(Path.GetExtension(c.OutFile), ".xlsx", StringComparison.OrdinalIgnoreCase) Then c.OutFile &= ".xlsx"
            If Not Directory.Exists(Path.GetDirectoryName(Path.GetFullPath(c.OutFile))) Then Throw New DirectoryNotFoundException("Output folder not found.")
            c.MatchDistanceMm = Convert.ToDouble(dist.Value)
            c.Dims = cd.Checked : c.Notes = cn.Checked : c.Gdt = cg.Checked
            c.Datums = ct.Checked : c.Views = cv.Checked : c.Excel = ce.Checked
            c.Capture = cp.Checked : c.Review = ch.Checked
            Return c
        End Using
    End Function

    Private Function Extract(p As Part, c As Config) As Snapshot
        Dim snap As New Snapshot()
        snap.FileName = p.FullPath
        snap.Units = p.PartUnits.ToString()
        s.ListingWindow.WriteLine("Extract: " & snap.FileName)
        Dim sheetTags As New Dictionary(Of Tag, String)()
        For Each sh As DraftingDrawingSheet In p.DraftingDrawingSheets.ToArray()
            sheetTags(sh.Tag) = sh.Name
            Dim shItem As New Item() With {.Category = "SHEET", .Kind = "Sheet", .Sheet = sh.Name, .Content = sh.Name, .Detail = "Size=" & F(sh.Length) & " x " & F(sh.Height) & " [" & sh.Units.ToString() & "] Projection=" & sh.ProjectionAngle.ToString(), .SourceTag = sh.Tag}
            snap.Sheets.Add(shItem)
            If c.Views Then
                Try
                    For Each v As DraftingView In sh.GetDraftingViews()
                        Dim item As New Item() With {.Category = "VIEW", .Kind = v.GetType().Name, .Sheet = sh.Name, .Content = v.Name, .Detail = "Scale=" & F(v.Scale), .SourceTag = v.Tag}
                        Try
                            Dim pt As Point3d = v.GetDrawingReferencePoint()
                            item.X = pt.X : item.Y = pt.Y : item.Z = pt.Z : item.Located = True
                        Catch ex As Exception
                            snap.Issues.Add("View origin inaccessible: " & v.Name & ": " & ex.Message)
                        End Try
                        snap.Items.Add(item)
                    Next
                Catch ex As Exception
                    snap.Issues.Add("Cannot enumerate views of sheet " & sh.Name & ": " & ex.Message)
                End Try
            End If
        Next
        If snap.Sheets.Count = 0 Then snap.Issues.Add("No drafting sheets found.")
        If c.Dims Then CycleAndExtract(p, UFConstants.UF_dimension_type, snap, sheetTags, c)
        If c.Notes OrElse c.Gdt OrElse c.Datums Then CycleAndExtract(p, UFConstants.UF_drafting_entity_type, snap, sheetTags, c)
        If c.Gdt Then snap.Issues.Add("FCF semantic segments, material modifiers and compound datums are NOT parsed; only object text is compared.")
        If c.Datums Then snap.Issues.Add("Datum-target validity and datum references are NOT structurally verified.")
        snap.Issues.Add("Sheet title-block attributes, weld/surface symbols, OCR, and formal drawing-standard compliance are outside Phase 1/2 scope.")
        s.ListingWindow.WriteLine("  Sheets=" & snap.Sheets.Count & ", extracted objects=" & snap.Items.Count)
        Return snap
    End Function

    Private Sub CycleAndExtract(p As Part, objectType As Integer, snap As Snapshot, sheetTags As Dictionary(Of Tag, String), c As Config)
        Dim t As Tag = Tag.Null
        Dim safety As Integer = 0
        Do
            uf.Obj.CycleObjsInPart(p.Tag, objectType, t)
            If t = Tag.Null Then Exit Do
            safety += 1
            If safety > 300000 Then
                snap.Issues.Add("Object cycling safety limit reached for type " & objectType.ToString())
                Exit Do
            End If
            Try
                Dim nxo As NXObject = TryCast(NXObjectManager.Get(t), NXObject)
                If nxo Is Nothing Then Continue Do
                Dim an As NXOpen.Annotations.Annotation = TryCast(nxo, NXOpen.Annotations.Annotation)
                If an Is Nothing Then Continue Do
                Dim d As NXOpen.Annotations.Dimension = TryCast(nxo, NXOpen.Annotations.Dimension)
                Dim it As New Item() With {.Kind = nxo.GetType().Name, .SourceTag = t}
                If d IsNot Nothing Then
                    If Not c.Dims Then Continue Do
                    it.Category = "DIMENSION"
                    Dim mt As String = ""
                    Try
                        mt = d.GetMeasurementType().ToString()
                    Catch
                        mt = it.Kind
                    End Try
                    it.Kind = it.Kind & "/" & mt
                    Dim scale As Double = If(p.PartUnits.ToString().Equals("Inches", StringComparison.OrdinalIgnoreCase), 25.4, 1.0)
                    If it.Kind.ToUpperInvariant().Contains("ANGULAR") Then scale = 1.0
                    it.Nominal = d.ComputedSize * scale
                    it.Upper = d.UpperToleranceValue * scale
                    it.Lower = d.LowerToleranceValue * scale
                    it.TolType = d.ToleranceType.ToString()
                    Dim m() As String = Nothing, dual() As String = Nothing
                    d.GetDimensionText(m, dual)
                    it.RawText = If(m Is Nothing, "", String.Join(" ", m))
                    If dual IsNot Nothing AndAlso dual.Length > 0 Then it.RawText &= " [DUAL " & String.Join(" ", dual) & "]"
                    it.Content = "Nominal=" & F(it.Nominal) & ";Tol=" & it.TolType & ";Upper=" & F(it.Upper) & ";Lower=" & F(it.Lower) & ";Text=" & it.RawText
                    it.Detail = "Dimension data; length output mm, angles native degree-type units"
                Else
                    Dim simple As NXOpen.Annotations.SimpleDraftingAid = TryCast(nxo, NXOpen.Annotations.SimpleDraftingAid)
                    If simple Is Nothing Then
                        snap.Issues.Add("Unsupported drafting annotation " & it.Kind & " Tag=" & t.ToString())
                        Continue Do
                    End If
                    If TypeOf nxo Is NXOpen.Annotations.Gdt Then
                        If Not c.Gdt AndAlso Not c.Datums Then Continue Do
                        If it.Kind.ToUpperInvariant().Contains("DATUM") Then
                            it.Category = "DATUM"
                            If Not c.Datums Then Continue Do
                        Else
                            it.Category = "GDT"
                            If Not c.Gdt Then Continue Do
                        End If
                    ElseIf it.Kind.ToUpperInvariant().Contains("DATUM") Then
                        it.Category = "DATUM"
                        If Not c.Datums Then Continue Do
                    ElseIf it.Kind.ToUpperInvariant().Contains("NOTE") OrElse it.Kind.ToUpperInvariant().Contains("LABEL") Then
                        it.Category = "NOTE"
                        If Not c.Notes Then Continue Do
                    Else
                        snap.Issues.Add("Unsupported drafting symbol: " & it.Kind & " Tag=" & t.ToString() & ". Not treated as a general note.")
                        it.Category = "UNVERIFIED"
                        it.ExtractionOk = False
                    End If
                    Dim lines() As String = simple.GetText()
                    it.RawText = If(lines Is Nothing, "", String.Join(" | ", lines))
                    it.Content = it.RawText
                    If it.Category = "GDT" OrElse it.Category = "DATUM" Then it.Detail = "Raw encoded text only: semantic validation UNVERIFIED"
                End If
                Dim po As Point3d = an.AnnotationOrigin
                it.X = po.X : it.Y = po.Y : it.Z = po.Z
                Dim factor As Double = If(p.PartUnits.ToString().Equals("Inches", StringComparison.OrdinalIgnoreCase), 25.4, 1.0)
                it.X *= factor : it.Y *= factor : it.Z *= factor
                it.Located = True
                it.Sheet = SheetFor(t, sheetTags, snap, an)
                snap.Items.Add(it)
            Catch ex As Exception
                snap.Issues.Add("Extraction ERROR tag " & t.ToString() & ": " & ex.Message)
                Dim broken As New Item() With {.Category = "UNVERIFIED", .Kind = "ExtractionFailure", .Content = ex.Message, .SourceTag = t, .ExtractionOk = False}
                snap.Items.Add(broken)
            End Try
        Loop
    End Sub

    Private Function SheetFor(t As Tag, names As Dictionary(Of Tag, String), snap As Snapshot, an As NXOpen.Annotations.Annotation) As String
        Try
            Dim status As Integer = 0
            Dim viewName As String = ""
            uf.View.AskViewDependentStatus(t, status, viewName)
            If status <> 0 AndAlso Not String.IsNullOrEmpty(viewName) Then
                Dim vt As Tag = Tag.Null, drawing As Tag = Tag.Null
                uf.View.AskTagOfViewName(viewName, vt)
                uf.Draw.AskDrawingOfView(vt, drawing)
                If names.ContainsKey(drawing) Then Return names(drawing)
            End If
        Catch ex As Exception
            snap.Issues.Add("Sheet association not resolved for tag " & t.ToString() & ": " & ex.Message)
        End Try
        ' NXOpen annotation-to-view association is the read-only fallback for objects
        ' that have no UF view-dependent status (e.g., some drafting aids).
        Try
            For Each av As NXOpen.View In an.GetViews()
                If names.ContainsKey(av.Tag) Then Return names(av.Tag)
                Try
                    Dim drawing As Tag = Tag.Null
                    uf.Draw.AskDrawingOfView(av.Tag, drawing)
                    If names.ContainsKey(drawing) Then Return names(drawing)
                Catch
                End Try
            Next
        Catch ex As Exception
            snap.Issues.Add("NX annotation GetViews failed for " & t.ToString() & ": " & ex.Message)
        End Try
        snap.Issues.Add("UNVERIFIED sheet association for tag " & t.ToString())
        Return "UNASSIGNED"
    End Function

    Private Function Audit(cur As Snapshot, reference As Snapshot, cfg As Config) As List(Of Finding)
        Dim output As New List(Of Finding)()
        If reference Is Nothing Then
            For Each it As Item In cur.Sheets
                AddFinding(output, it.Category, it.Sheet, "", it.Detail, "UNVERIFIED", "Extraction only; no reference drawing", it.SourceTag)
            Next
            For Each it As Item In cur.Items
                AddFinding(output, it.Category, it.Sheet, "", it.Content, "UNVERIFIED", "Extraction only; no reference drawing", it.SourceTag)
            Next
            Return output
        End If
        ' Stage 1: sheets matched by exact sheet name only. No invented index equivalence.
        For Each r As Item In reference.Sheets
            Dim candidates As New List(Of Item)()
            For Each a As Item In cur.Sheets
                If String.Equals(a.Sheet, r.Sheet, StringComparison.OrdinalIgnoreCase) Then candidates.Add(a)
            Next
            If candidates.Count = 1 Then
                Dim a As Item = candidates(0)
                a.Used = True
                Dim same As Boolean = (a.Detail = r.Detail)
                AddFinding(output, "SHEET", r.Sheet, r.Detail, a.Detail, If(same, "PASS", "FAIL"), If(same, "Sheet details agree", "Sheet size, units or projection differ"), a.SourceTag)
            ElseIf candidates.Count = 0 Then
                AddFinding(output, "SHEET", r.Sheet, r.Detail, "", "MISSING", "Reference sheet name not found (renamed sheets need manual mapping)", Tag.Null)
            Else
                AddFinding(output, "SHEET", r.Sheet, r.Detail, "", "UNVERIFIED", "Duplicate matching sheet names", Tag.Null)
            End If
        Next
        For Each a As Item In cur.Sheets
            If Not a.Used Then AddFinding(output, "SHEET", a.Sheet, "", a.Detail, "EXTRA", "Sheet exists only in current drawing", a.SourceTag)
        Next
        ' Stage 2: unique semantic/text matches on an explicitly named sheet.
        ' Stage 3: strictly unique spatial candidate for changed annotations; ambiguous => UNVERIFIED.
        For Each r As Item In reference.Items
            If Not r.ExtractionOk OrElse r.Sheet = "UNASSIGNED" Then
                AddFinding(output, r.Category, r.Sheet, r.Content, "", "UNVERIFIED", "Reference extraction or sheet association uncertain", Tag.Null)
                Continue For
            End If
            Dim exacts As New List(Of Item)()
            For Each a As Item In cur.Items
                If a.Used OrElse Not a.ExtractionOk Then Continue For
                If a.Category <> r.Category OrElse a.Sheet <> r.Sheet Then Continue For
                If a.Kind <> r.Kind Then Continue For
                If String.Equals(a.Content, r.Content, StringComparison.Ordinal) Then exacts.Add(a)
            Next
            If exacts.Count = 1 Then
                exacts(0).Used = True
                Dim verdict As String = If(r.Category = "GDT" OrElse r.Category = "DATUM", "UNVERIFIED", "PASS")
                AddFinding(output, r.Category, r.Sheet, r.Content, exacts(0).Content, verdict, If(verdict = "PASS", "Exact content match", "Raw text matches; semantic GD&T still unverified"), exacts(0).SourceTag)
                Continue For
            End If
            If exacts.Count > 1 Then
                For Each e As Item In exacts : e.Ambiguous = True : Next
                AddFinding(output, r.Category, r.Sheet, r.Content, "", "UNVERIFIED", "Multiple exact candidates; cannot uniquely identify object", Tag.Null)
                Continue For
            End If
            Dim near As New List(Of Item)()
            For Each a As Item In cur.Items
                If a.Used OrElse Not a.ExtractionOk Then Continue For
                If a.Sheet <> r.Sheet OrElse a.Category <> r.Category OrElse a.Kind <> r.Kind Then Continue For
                If Not a.Located OrElse Not r.Located Then Continue For
                Dim dx As Double = a.X - r.X, dy As Double = a.Y - r.Y
                Dim distance As Double = Math.Sqrt(dx * dx + dy * dy)
                If distance <= cfg.MatchDistanceMm Then near.Add(a)
            Next
            If near.Count = 1 Then
                Dim a As Item = near(0)
                a.Used = True
                Dim result As String = If(r.Category = "GDT" OrElse r.Category = "DATUM", "UNVERIFIED", "FAIL")
                AddFinding(output, r.Category, r.Sheet, r.Content, a.Content, result, If(result = "FAIL", "Unique nearby object differs", "Changed raw GD&T text; requires semantic human review"), a.SourceTag)
            ElseIf near.Count = 0 Then
                AddFinding(output, r.Category, r.Sheet, r.Content, "", "MISSING", "No matching object found (could have been moved or sheet renamed)", Tag.Null)
            Else
                For Each e As Item In near : e.Ambiguous = True : Next
                AddFinding(output, r.Category, r.Sheet, r.Content, "", "UNVERIFIED", "Multiple nearby candidates: cannot establish a safe match", Tag.Null)
            End If
        Next
        For Each a As Item In cur.Items
            If a.Used Then Continue For
            If Not a.ExtractionOk OrElse a.Sheet = "UNASSIGNED" OrElse a.Ambiguous Then
                AddFinding(output, a.Category, a.Sheet, "", a.Content, "UNVERIFIED", "Current object extraction or sheet uncertain", a.SourceTag)
            Else
                AddFinding(output, a.Category, a.Sheet, "", a.Content, "EXTRA", "No unique reference match", a.SourceTag)
            End If
        Next
        Return output
    End Function

    Private Sub AddFinding(dest As List(Of Finding), cat As String, sh As String, r As String, c As String, status As String, reason As String, t As Tag)
        Dim f As New Finding()
        f.Id = "CHK-" & (dest.Count + 1).ToString("00000")
        f.Category = cat : f.Sheet = sh
        f.Reference = r : f.Current = c : f.Status = status : f.Reason = reason : f.CurrentTag = t
        dest.Add(f)
    End Sub

    Private Function F(v As Double) As String
        Return v.ToString("0.######", ci)
    End Function

    Private Sub ExportReport(cfg As Config, cur As Snapshot, r As Snapshot, findings As List(Of Finding))
        Dim warnings As New List(Of String)()
        warnings.AddRange(cur.Issues)
        If r IsNot Nothing Then warnings.AddRange(r.Issues)
        warnings.Add("NOTE: Only the currently displayed NX graphics view can be captured; complete current/reference sheet image pairs are NOT implemented.")
        warnings.Add("NOTE: Matching on text and annotation position does not establish CAD geometry associativity.")
        warnings.Add("NOTE: Native NX parts are NOT saved. Drawing reference remains open in NX if it was opened by this journal.")
        Dim statuses As New Dictionary(Of String, Integer)(StringComparer.OrdinalIgnoreCase)
        For Each f As Finding In findings
            If Not statuses.ContainsKey(f.Status) Then statuses(f.Status) = 0
            statuses(f.Status) += 1
        Next
        Dim overall As String = "PASS"
        If statuses.ContainsKey("FAIL") OrElse statuses.ContainsKey("MISSING") OrElse statuses.ContainsKey("EXTRA") Then overall = "FAIL"
        If statuses.ContainsKey("UNVERIFIED") OrElse statuses.ContainsKey("ERROR") OrElse warnings.Count > 0 Then
            overall = If(overall = "FAIL", "FAIL - INCOMPLETE", "INCOMPLETE / UNVERIFIED")
        End If
        Dim screenPath As String = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(cfg.OutFile)), Path.GetFileNameWithoutExtension(cfg.OutFile) & "_active_NX_view.png")
        Dim captured As Boolean = False
        If cfg.Capture Then
            Try
                uf.Disp.CreateImage(screenPath, UFDisp.ImageFormat.Png, UFDisp.BackgroundColor.White) ' Deprecated in SC2306; confirm on installed machine
                captured = File.Exists(screenPath)
                If Not captured Then warnings.Add("Active NX graphics image could not be created.")
            Catch ex As Exception
                warnings.Add("NX graphics capture failed (deprecated UF API): " & ex.Message)
            End Try
        End If
        If cfg.Excel Then
            Dim excel As Object = Nothing, wb As Object = Nothing
            Dim sheets As New List(Of Object)()
            Try
                excel = CreateObject("Excel.Application")
                excel.Visible = False : excel.DisplayAlerts = False
                wb = excel.Workbooks.Add()
                Dim sum As Object = wb.Worksheets(1)
                sum.Name = "Inspection Summary" : sheets.Add(sum)
                sum.Cells(1, 1).Value = "NX 2306 DRAWING CHECKER - LIMITED PHASE 1/2"
                sum.Cells(2, 1).Value = "Current drawing" : sum.Cells(2, 2).Value = SafeExcel(cur.FileName)
                sum.Cells(3, 1).Value = "Reference drawing" : sum.Cells(3, 2).Value = SafeExcel(If(r Is Nothing, "(extraction only)", r.FileName))
                sum.Cells(4, 1).Value = "Date/time" : sum.Cells(4, 2).Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                sum.Cells(5, 1).Value = "Inspection status" : sum.Cells(5, 2).Value = overall
                sum.Cells(6, 1).Value = "Total results" : sum.Cells(6, 2).Value = findings.Count
                Dim k As Integer = 7
                For Each st As KeyValuePair(Of String, Integer) In statuses
                    sum.Cells(k, 1).Value = st.Key : sum.Cells(k, 2).Value = st.Value : k += 1
                Next
                sum.Cells(1, 1).Font.Bold = True
                sum.Columns("A:B").AutoFit()
                Dim det As Object = wb.Worksheets.Add(After:=sum)
                det.Name = "Detailed Comparison" : sheets.Add(det)
                Dim headers() As String = {"ID", "Category", "Sheet", "Reference", "Current", "Status", "Reason"}
                For j As Integer = 0 To headers.Length - 1 : det.Cells(1, j + 1).Value = headers(j) : Next
                det.Rows(1).Font.Bold = True
                For i As Integer = 0 To findings.Count - 1
                    Dim f As Finding = findings(i), rr As Integer = i + 2
                    det.Cells(rr, 1).Value = f.Id : det.Cells(rr, 2).Value = f.Category
                    det.Cells(rr, 3).Value = f.Sheet : det.Cells(rr, 4).Value = SafeExcel(f.Reference)
                    det.Cells(rr, 5).Value = SafeExcel(f.Current) : det.Cells(rr, 6).Value = f.Status
                    det.Cells(rr, 7).Value = SafeExcel(f.Reason)
                Next
                det.Columns("A:G").AutoFit()
                Dim diff As Object = wb.Worksheets.Add(After:=det)
                diff.Name = "Missing Modified" : sheets.Add(diff)
                For j As Integer = 0 To headers.Length - 1 : diff.Cells(1, j + 1).Value = headers(j) : Next
                diff.Rows(1).Font.Bold = True
                Dim dr As Integer = 2
                For Each f As Finding In findings
                    If f.Status = "PASS" Then Continue For
                    diff.Cells(dr, 1).Value = f.Id : diff.Cells(dr, 2).Value = f.Category
                    diff.Cells(dr, 3).Value = f.Sheet : diff.Cells(dr, 4).Value = SafeExcel(f.Reference)
                    diff.Cells(dr, 5).Value = SafeExcel(f.Current) : diff.Cells(dr, 6).Value = f.Status
                    diff.Cells(dr, 7).Value = SafeExcel(f.Reason) : dr += 1
                Next
                diff.Columns("A:G").AutoFit()
                Dim imgs As Object = wb.Worksheets.Add(After:=diff)
                imgs.Name = "Drawing Images" : sheets.Add(imgs)
                imgs.Cells(1, 1).Value = "Active NX graphics view (NOT whole-sheet comparison)"
                imgs.Cells(2, 1).Value = "Reference image and per-sheet comparisons not implemented. Graphics image capture uses deprecated NX API."
                imgs.Columns("A:A").ColumnWidth = 110
                If captured Then
                    Try
                        imgs.Shapes.AddPicture(screenPath, 0, -1, 20, 65, 720, 450)
                    Catch ex As Exception
                        warnings.Add("Cannot embed screenshot in Excel: " & ex.Message)
                    End Try
                End If
                Dim ws As Object = wb.Worksheets.Add(After:=imgs)
                ws.Name = "Validation Log" : sheets.Add(ws)
                ws.Cells(1, 1).Value = "Limitations, warnings and extraction diagnostics"
                ws.Rows(1).Font.Bold = True
                For i As Integer = 0 To warnings.Count - 1 : ws.Cells(i + 2, 1).Value = SafeExcel(warnings(i)) : Next
                ws.Columns("A:A").ColumnWidth = 125
                wb.SaveAs(Path.GetFullPath(cfg.OutFile), 51) ' 51=Excel Open XML workbook (*.xlsx)
                s.ListingWindow.WriteLine("Excel saved: " & Path.GetFullPath(cfg.OutFile))
                Return
            Catch ex As Exception
                s.ListingWindow.WriteLine("Excel unavailable or export failed: " & ex.Message & ". Writing CSV fallback.")
            Finally
                Try
                    If wb IsNot Nothing Then wb.Close(False)
                Catch
                End Try
                Try
                    If excel IsNot Nothing Then excel.Quit()
                Catch
                End Try
                For Each sh As Object In sheets
                    If Marshal.IsComObject(sh) Then Marshal.FinalReleaseComObject(sh)
                Next
                If wb IsNot Nothing AndAlso Marshal.IsComObject(wb) Then Marshal.FinalReleaseComObject(wb)
                If excel IsNot Nothing AndAlso Marshal.IsComObject(excel) Then Marshal.FinalReleaseComObject(excel)
            End Try
        End If
        Dim stem As String = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(cfg.OutFile)), Path.GetFileNameWithoutExtension(cfg.OutFile))
        Using sw As New StreamWriter(stem & "_comparison.csv", False, New UTF8Encoding(True))
            sw.WriteLine("ID,Category,Sheet,Reference,Current,Status,Reason")
            For Each f As Finding In findings
                sw.WriteLine(String.Join(",", New String(){Q(f.Id), Q(f.Category), Q(f.Sheet), Q(f.Reference), Q(f.Current), Q(f.Status), Q(f.Reason)}))
            Next
        End Using
        Using sw As New StreamWriter(stem & "_warnings.csv", False, New UTF8Encoding(True))
            sw.WriteLine("Warning")
            For Each w As String In warnings : sw.WriteLine(Q(w)) : Next
        End Using
        s.ListingWindow.WriteLine("CSV fallback saved: " & stem & "_comparison.csv")
    End Sub

    Private Sub ReviewFindings(findings As List(Of Finding))
        Using dlg As New Form()
            dlg.Text = "NX Drawing Checker - Review Findings"
            dlg.Width = 830 : dlg.Height = 520
            dlg.StartPosition = FormStartPosition.CenterScreen
            Dim list As New ListBox() With {.Left = 10, .Top = 10, .Width = 790, .Height = 385, .HorizontalScrollbar = True}
            For Each f As Finding In findings
                list.Items.Add(f.Id & "  " & f.Status.PadRight(11) & "  " & f.Category.PadRight(12) & "  " & f.Sheet & " : " & f.Reason)
            Next
            dlg.Controls.Add(list)
            Dim hi As New Button() With {.Text = "Highlight selected", .Left = 10, .Top = 408, .Width = 160}
            Dim clr As New Button() With {.Text = "Clear highlight", .Left = 183, .Top = 408, .Width = 140}
            Dim done As New Button() With {.Text = "Close", .Left = 685, .Top = 408, .Width = 115, .DialogResult = DialogResult.OK}
            Dim lbl As New Label() With {.Text = "Highlights only a visible object on the displayed sheet; source formatting stays unchanged.", .Left = 10, .Top = 449, .Width = 770}
            dlg.Controls.AddRange(New Control(){hi, clr, done, lbl})
            dlg.AcceptButton = done
            Dim active As DisplayableObject = Nothing
            AddHandler hi.Click, Sub(sender, e)
                                     If active IsNot Nothing Then
                                         Try
                                             active.Unhighlight()
                                         Catch
                                         End Try
                                         active = Nothing
                                     End If
                                     If list.SelectedIndex < 0 Then Return
                                     Dim f As Finding = findings(list.SelectedIndex)
                                     If f.CurrentTag = Tag.Null Then
                                         MessageBox.Show("No corresponding current drawing object for this finding.")
                                         Return
                                     End If
                                     Try
                                         active = TryCast(NXObjectManager.Get(f.CurrentTag), DisplayableObject)
                                         If active Is Nothing Then Throw New Exception("Object is not displayable")
                                         active.Highlight()
                                     Catch ex As Exception
                                         MessageBox.Show("Cannot highlight: " & ex.Message)
                                     End Try
                                 End Sub
            AddHandler clr.Click, Sub(sender, e)
                                      If active IsNot Nothing Then
                                          Try
                                             active.Unhighlight()
                                         Catch
                                         End Try
                                          active = Nothing
                                      End If
                                  End Sub
            Try
                dlg.ShowDialog()
            Finally
                If active IsNot Nothing Then
                    Try
                                             active.Unhighlight()
                                         Catch
                                         End Try
                End If
            End Try
        End Using
    End Sub

    Private Function SafeExcel(v As String) As String
        Dim t As String = If(v, "")
        If t.Length > 0 AndAlso "=+-@".IndexOf(t(0)) >= 0 Then Return "'" & t
        Return t
    End Function

    Private Function Q(v As String) As String
        ' CSV formula injection prevention: prefix untrusted text interpreted as spreadsheet formulas.
        Dim t As String = If(v, "")
        If t.Length > 0 AndAlso "=+-@".IndexOf(t(0)) >= 0 Then t = "'" & t
        Return """" & t.Replace("""", """""") & """"
    End Function

    Public Function GetUnloadOption(ByVal dummy As String) As Integer
        Return CInt(Session.LibraryUnloadOption.Immediately)
    End Function
End Module
