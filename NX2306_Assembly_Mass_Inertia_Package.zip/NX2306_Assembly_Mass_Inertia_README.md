# NX 2306 Assembly Mass and Inertia Journal

Source: `NX2306_Assembly_Mass_Inertia_Report.vb` (single file, VB.NET)

## Launch

1. Start NX 2306 (Windows) and open the top-level assembly.
2. Make the displayed top-level assembly also the **Work Part**. Load all required components with exact geometry and review their active reference sets. Set a readable graphics view.
3. Go to **Tools → Journal → Play** and select the `.vb` file.
4. In the form, choose *Entire active assembly* or *Visible solid bodies only*.
5. Optionally enter a fallback density, in **kg/m³** or **g/cm³**. Leave it blank to exclude bodies without assigned material rather than silently assigning density.
6. Choose Excel export and/or an optional NX native table. For Excel export, pick the `.xlsx` filename in the Save As dialog.
7. For the NX table, activate a drawing sheet if required, confirm its creation, and click a table location in NX. The journal never saves the NX assembly.

## Output

- `.xlsx`: **Summary**, **Components**, **Warnings** sheets; formatted summary with captured view (when screenshot succeeds).
- `_NX_View.png`: the current graphics view (when capture succeeds).
- If Excel is not installed or COM SaveAs fails: `_Summary.csv`, `_Components.csv`, `_Warnings.csv` and, when successful, the `.png`. CSV files cannot embed an image.
- NX Listing Window: values and warnings.
- Optional unsaved native NX tabular note.

## Reference, units and mathematical method

- UF mass property calculation uses `UFModl.AskMassProps3d` with output units kg / metres, and converts the reported WCS centroid to assembly ABS using `UFCsys.MapPoint`.
- The inertia tensor is rotated from WCS to assembly ABS-parallel axes. The parallel-axis theorem combines each measured occurrence about the common assembly CG.
- Final units: kg; mm; kg·mm². Principal moments are sorted ascending.
- Reported products: Ixy = +∫x'y' dm, Ixz = +∫x'z' dm, Iyz = +∫y'z' dm. Corresponding mathematical inertia-tensor off-diagonals are negative these values.
- Material assignment is checked against the physical-material collection. `Body.Density` is expressed in kg/m³. An explicit fallback is used only when a physical material is missing or density is invalid. Density is never changed in NX.

## Limitations / required on-site validation

- Published NXOpen 2306 APIs were researched, but this journal was **not compiled or executed inside NX 2306** in this environment; validate against the installed NXOpen.dll and NXOpen.UF.dll.
- UF screenshot capture `UFDisp.CreateImage` is present but deprecated. Confirm that the installed `ImageFormat` supports PNG, and test image capture in a visible NX graphics view.
- Check the installed `.NET` signature for `PhysicalMaterialCollection.FindBodiesWithoutMaterial`. The journal looks up this documented function via reflection, marking its output incomplete if the query fails.
- The NX tabular note `UFTabnot.Create` is documented, but table creation and screen positioning depend on the active Drafting vs Modeling application; record a table-placement journal on your installation if this step fails.
- Only bodies in active assembly occurrence/reference-set context can be measured. Lightweight, partially loaded, unavailable or excluded reference-set bodies are flagged, but use *Load Fully / Exact* before relying on a full assembly result.
- The **entire assembly** scope includes blanked but active occurrence bodies; the visible-only scope tests `Body.IsBlanked`. Layer/scene visibility and hidden parent component handling should be cross-checked on site.
- Repeated instances with separate occurrence tags are counted once each. Geometrically overlapping distinct bodies (e.g. WAVE-linked clones) cannot be automatically identified as duplicates.
- NX work part must be the displayed top-level assembly to keep WCS/ABS interpretation unambiguous. The journal does not change work part.
- Excel desktop is needed for true `.xlsx` export (late-bound COM; no interop reference needed). The CSV fallback works without Excel.
- The numeric output is not an associative live mass property measurement; rerun after assembly/model changes.

## Validation procedure

1. Create a single rectangular block of known dimensions and known assigned density. Run both NX **Analysis → Measure Bodies** and this journal at the same accuracy. Compare mass and CG.
2. Rotate and translate one block occurrence; compare mass invariance, transformed CG, and tensor/principal moments with NX's measurements.
3. Create two repeated occurrences of the same part and verify doubled mass and correct global CG/inertia (without accidental prototype/occurrence double counting).
4. Put one component in an inch part and another in a millimetre part; verify all reported values remain in kg, mm, kg·mm².
5. Change the WCS origin and rotate the WCS, but not geometry; rerun and verify results in **assembly ABS** are unchanged.
6. Remove a body material; verify exclusion and **INCOMPLETE** without fallback. Enter an explicit fallback density; verify the warning and recalculated mass while the original model density remains untouched.
7. Partially unload a component, select a lightweight representation, or exclude solid bodies using a reference set. Verify warning/status instead of a falsely complete answer.
8. Remove Excel or disable Excel automation, and verify CSV output and PNG handling.
9. Opt into native tabular note creation on a drawing sheet, then cancel the same selection in another run and check the model is never automatically saved.

## Required DLLs

NX journal host supplies Siemens assemblies: `NXOpen.dll`, `NXOpen.UF.dll`, `NXOpen.Utilities.dll`, `NXOpenUI.dll`. Uses Windows standard `System`, `System.Core`, `System.Windows.Forms`, `System.Runtime.InteropServices` support. On a compiled `.dll` project rather than journal play, reference these from your NX 2306 `NXBIN` installation as appropriate.
